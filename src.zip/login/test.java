/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

/**
 *
 * @author David
 */


public class test {
    
     public static void main(String[] args)
    {
        int[] col = {7,3,1,5,8,2,6,4,9,10};
        double min = 5, max = 1, temp = 1;
        double avg;
        for(int k = 0; k < col.length; k++){
            min = col[0];
            max = col[0];
            for (int z = 1; z < 9; z++){
            if (col[z +1] < min) {
            temp = min;
            min = col[z+1];
        }
            }
            
            if (col[k] > max){
             temp = max;
             max = col[k];
            }
        }
        avg = (max + min)/2.0;
        
        System.out.print("min: " + min +"    " + "avg: " +avg + "   " + "max: " + max  );
    }
    
}
