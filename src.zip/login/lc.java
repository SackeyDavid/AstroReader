/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

/**
 *
 * @author David
 */

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;


public class lc implements Initializable {
    
    
        
     @FXML 
    private ImageView imageviewer;
    
    @FXML 
    private AnchorPane roote;
       
    public static StackPane rootP;
    
    @FXML 
    private ProgressBar progressbar;
    
    

    
//   @FXML
//    private StackPane rootPane;
//    
//    public static StackPane rootP;
//    
//    @FXML
//    private TextField usertext;
//    
//    @FXML
//    private PasswordField passwordfield;
//    
//    @FXML
//    private Pane panel;
//    
//    @FXML
//    private ImageView imageviewer;
//    
//    @FXML
//    private Separator separator;
//    
//    @FXML
//    private Label username;
//    
//    @FXML
//    private Label password;
//    
//    @FXML
//    private Label level;
//    
//    @FXML
//    private ComboBox combo;
//    
//    @FXML
//    private Button signin;
//    

    
    
   
    

@Override
    public void initialize(URL url, ResourceBundle rb) {
        new SplashScreen().start();
    }
        
    
    class SplashScreen extends Thread {
    @Override
    public void run()
    {
                    roote.setStyle("-fx-border-color:black; -fx-border-width: 1px;");
 
                   try { 
                    Thread.sleep(5000);
                    
                    Platform.runLater(new Runnable() {
                         
                    @Override
                    public void run(){
                        Parent root = null;
                    try {
                       
                        root = FXMLLoader.load(getClass().getResource("TableView.fxml"));
                        
                        
                    }   catch (IOException ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    Scene scene = new Scene(root);
                    
                    Stage Stage = new Stage();
                    //set icon of the application
                    Image applicationIcon = new Image(getClass().getResourceAsStream("radio.png"));
                    Stage.getIcons().add(applicationIcon);
                    Stage.setScene(scene);
                    Stage.setTitle("AstroReader 1.0");
                    Stage.show();
                    roote.getScene().getWindow().hide();
                    
                    
                    
                    
                    }
                 });
               
    } catch (InterruptedException ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
         }
     }
  }
    
}
