///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package login;
//
///**
// *
// * @author David
// */
//
//
//import java.util.Arrays;
//import java.util.List;
//import javafx.application.Application;
//import static javafx.application.Application.launch;
//import javafx.beans.property.SimpleDoubleProperty;
//import javafx.beans.property.SimpleStringProperty;
//import javafx.collections.FXCollections;
//import javafx.collections.ObservableList;
//import javafx.event.EventHandler;
//import javafx.scene.Group;
//import javafx.scene.Scene;
//import javafx.scene.chart.CategoryAxis;
//import javafx.scene.chart.LineChart;
//import javafx.scene.chart.NumberAxis;
//import javafx.scene.chart.PieChart;
//import javafx.scene.chart.XYChart;
//import javafx.scene.control.ContentDisplay;
//import javafx.scene.control.TableCell;
//import javafx.scene.control.TableColumn;
//import javafx.scene.control.TableView;
//import javafx.scene.control.TextField;
//import javafx.scene.control.cell.PropertyValueFactory;
//import javafx.scene.input.KeyCode;
//import javafx.scene.input.KeyEvent;
//import javafx.scene.layout.HBox;
//import javafx.stage.Stage;
//import javafx.util.Callback;
//
//
//
//public class JavaFXColumnChart {
//            
//                   class MyList {
//         
//        ObservableList<logEntry> dataList;
//        ObservableList<PieChart.Data> pieChartData1;
//        ObservableList<XYChart.Data> xyList2;
//         
//        MyList(){
//            dataList = FXCollections.observableArrayList();
//            pieChartData1 = FXCollections.observableArrayList();
//            xyList2 = FXCollections.observableArrayList();
//        }
//         
//        public void add(logEntry r){
//            dataList.add(r);
//            xyList2.add(new XYChart.Data(r.getTime(), r.getUpSlow()));
//        }
//         
//        
//    }
//     
//    MyList myList; 
//     
//    private TableView<logEntry> tableView = new TableView<>();
//     
//    public static void main(String[] args) {
//        launch(args);
//    }
//     
//    @Override 
//    public void start(Stage primaryStage) {
//        primaryStage.setTitle("java-buddy.blogspot.com");
//         
//        //prepare myList
//        myList = new MyList();
//         
//        Group root = new Group();
//         
//        tableView.setEditable(true);
// 
//        Callback<TableColumn, TableCell> cellFactory = 
//                new Callback<TableColumn, TableCell>() {
//                           
//                          @Override
//                          public TableCell call(TableColumn p) {
//                              return new EditingCell();
//                          }
//                      };
//         
//        TableColumn columnDay = new TableColumn("Day");
//        columnDay.setCellValueFactory(
//                new PropertyValueFactory<logEntry,String>("fieldDay"));
//        columnDay.setMinWidth(60);
//         
//        TableColumn columnValue1 = new TableColumn("Value 1");
//        columnValue1.setCellValueFactory(
//                new PropertyValueFactory<logEntry,Double>("fieldValue1"));
//        columnValue1.setMinWidth(60);
//         
//        TableColumn columnValue2 = new TableColumn("Value 2");
//        columnValue2.setCellValueFactory(
//                new PropertyValueFactory<logEntry,Double>("fieldValue2"));
//        columnValue2.setMinWidth(60);
//      
//        //--- Add for Editable Cell of Value field, in Double
//        
//       
//        //--- Prepare StackedBarChart
//         
//        List<String> dayLabels = Arrays.asList(
//		"1","2","3","4","5","6","7");
// 
//        
//         
//        final CategoryAxis xAxis2 = new CategoryAxis();
//        final NumberAxis yAxis2 = new NumberAxis();
//        xAxis2.setLabel("Day");
//        xAxis2.setCategories(FXCollections.<String> observableArrayList(dayLabels));
//        yAxis2.setLabel("Value 2");
//        XYChart.Series XYSeries2 = new XYChart.Series(myList.xyList2);
//        XYSeries2.setName("XYChart.Series 2");
//         
//        final LineChart<String,Number> lineChart2 = 
//                new LineChart<>(xAxis2,yAxis2);
//        lineChart2.setTitle("Line Chart 2");
//        lineChart2.setPrefWidth(250);
//        lineChart2.getData().add(XYSeries2);
// 
//        //---
//        tableView.setItems(myList.dataList);
//        tableView.getColumns().addAll(columnValue1, columnValue2);
//        tableView.setPrefWidth(200);
//         
//        HBox hBox = new HBox();
//        hBox.setSpacing(10);
//        hBox.getChildren().addAll(tableView, lineChart2);
//  
//        root.getChildren().add(hBox);
//      
//      primaryStage.setScene(new Scene(root, 750, 400));
//      primaryStage.show();
//    }
// 
//    class EditingCell extends TableCell<logEntry, Double> {
//        private TextField textField;
//         
//        public EditingCell() {}
//         
//        @Override
//        public void startEdit() {
//            super.startEdit();
//             
//            if (textField == null) {
//                createTextField();
//            }
//             
//            setGraphic(textField);
//            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
//            textField.selectAll();
//        }
//         
//        @Override
//        public void cancelEdit() {
//            super.cancelEdit();
//             
//            setText(String.valueOf(getItem()));
//            setContentDisplay(ContentDisplay.TEXT_ONLY);
//        }
//         
//        @Override
//        public void updateItem(Double item, boolean empty) {
//            super.updateItem(item, empty);
//          
//            if (empty) {
//                setText(null);
//                setGraphic(null);
//            } else {
//                if (isEditing()) {
//                    if (textField != null) {
//                        textField.setText(getString());
//                    }
//                     
//                    setGraphic(textField);
//                    setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
//                } else {
//                    setText(getString());
//                    setContentDisplay(ContentDisplay.TEXT_ONLY);
//                }
//            }
//        }
//         
//        private void createTextField() {
//            textField = new TextField(getString());
//            textField.setMinWidth(this.getWidth() - this.getGraphicTextGap()*2);
//            textField.setOnKeyPressed(new EventHandler<KeyEvent>() {
//              
//                @Override
//                public void handle(KeyEvent t) {
//                    if (t.getCode() == KeyCode.ENTER) {
//                        commitEdit(Double.parseDouble(textField.getText()));
//                    } else if (t.getCode() == KeyCode.ESCAPE) {
//                        cancelEdit();
//                    }
//                }
//            });
//        }
//      
//        private String getString() {
//            return getItem() == null ? "" : getItem().toString();
//        }
//    }
//}
