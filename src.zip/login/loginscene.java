/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

/**
 *
 * @author David
 */


import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ToolBar;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.stage.StageStyle;



public class loginscene extends Application{
    
         
     @Override
    public void start (Stage primaryStage) throws Exception {
        
        Parent root = FXMLLoader.load(getClass().getResource("/login/tv.fxml"));

            Scene scene = new Scene(root);
            BorderPane borderPane = new BorderPane();
          
            primaryStage.initStyle(StageStyle.UNDECORATED);
            primaryStage.setScene( scene);
            //set icon of the application
            Image applicationIcon = new Image(getClass().getResourceAsStream("radio.png"));
            primaryStage.getIcons().add(applicationIcon);
            primaryStage.show();
        
            String css = loginscene.class.getResource("splash.css").toExternalForm();
            scene.getStylesheets().add(css);
          
    }
    /**
     * 
     * @param args 
     */
     public static void main(String[] args) {
        launch(args);
    }
    
    

}

