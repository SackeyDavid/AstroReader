package login;

import java.util.Observable;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart.Data;
import javafx.scene.chart.XYChart;
import javafx.scene.control.TableColumn;

//class for log entry
public class logEntry 
{
//    
//                    private final IntegerProperty firstName = new SimpleStringProperty(this, "firstName", null);
//                    private final StringProperty lastName = new SimpleStringProperty(this, "lastName", null);
//                    private final StringProperty phoneNumber = new SimpleStringProperty(this, "phoneNumber", null);
//                    private final StringProperty emailAddress = new SimpleStringProperty(this, "emailAddress", null);
                
                public final StringProperty     time = new SimpleStringProperty(this, "time", null);
                public final StringProperty     upSlow = new SimpleStringProperty(this, "upSlow", null);
                public final StringProperty     upFast = new SimpleStringProperty(this, "upFast", null);
                public final StringProperty     dnSlow = new SimpleStringProperty(this, "dnSlow", null);
                public final StringProperty     dnFast = new SimpleStringProperty(this, "dnFast", null);
                public final StringProperty     rtSlow = new SimpleStringProperty(this, "rtSlow", null);
                public final StringProperty     rtFast = new SimpleStringProperty(this, "rtFast", null);
                public final StringProperty     ltSlow = new SimpleStringProperty(this, "ltSlow", null);
                public final StringProperty     ltFast = new SimpleStringProperty(this, "ltFast", null);
                public final StringProperty     feedAcc = new SimpleStringProperty(this, "feedAcc", null);
                public final StringProperty     stow = new SimpleStringProperty(this, "stow", null);
                public final StringProperty     remote = new SimpleStringProperty(this, "remote", null);
                public final StringProperty     local = new SimpleStringProperty(this, "local", null);
                public final StringProperty     VtripE380 = new SimpleStringProperty(this, "VtripE380", null);
                public final StringProperty     brkRoffE = new SimpleStringProperty(this, "brkRoffE", null);
                public final StringProperty     VonE24 = new SimpleStringProperty(this, "VonE24", null);
                public final StringProperty     Voff380 = new SimpleStringProperty(this, "Voff380", null);
                public final StringProperty     VtripA380 = new SimpleStringProperty(this, "VtripA380", null);
                public final StringProperty     brkRoffA = new SimpleStringProperty(this, "brkRoffA", null);
                public final StringProperty     VonA24 = new SimpleStringProperty(this, "VonA24", null);
                public final StringProperty     Von24 = new SimpleStringProperty(this, "Von24", null);
                public final StringProperty     overHlim = new SimpleStringProperty(this, "overHlim", null);
                public final StringProperty     tBoxOver = new SimpleStringProperty(this, "tBoxOver", null);
                public final StringProperty     notEstop = new SimpleStringProperty(this, "notEstop", null);
                public final StringProperty     overlap1 = new SimpleStringProperty(this, "overlap1", null);
                public final StringProperty     enReqE = new SimpleStringProperty(this, "enReqE", null);
                public final StringProperty     enE = new SimpleStringProperty(this, "enE", null);
                public final StringProperty     topHlim = new SimpleStringProperty(this, "topHlim", null);
                public final StringProperty     botHlim = new SimpleStringProperty(this, "botHlim", null);
                public final StringProperty     notTopFlim = new SimpleStringProperty(this, "notTopFlim", null);
                public final StringProperty     notBotFlim = new SimpleStringProperty(this, "notBotFlim", null);
                public final StringProperty     bkStow = new SimpleStringProperty(this, "bkStow", null);
                public final StringProperty     brakeE = new SimpleStringProperty(this, "brakeE", null);
                public final StringProperty     enReqA = new SimpleStringProperty(this, "enReqA", null);
                public final StringProperty     enA = new SimpleStringProperty(this, "enA", null);
                public final StringProperty     rtHlim = new SimpleStringProperty(this, "rtHlim", null);
                public final StringProperty     ltHlim = new SimpleStringProperty(this, "ltHlim", null);
                public final StringProperty     notRtFlim = new SimpleStringProperty(this, "notRtFlim", null);
                public final StringProperty     notLtFlim = new SimpleStringProperty(this, "notLtFlim", null);
                public final StringProperty     overlap2 = new SimpleStringProperty(this, "overlap2", null);
                public final StringProperty     brakeA = new SimpleStringProperty(this, "brakeA", null);
                public final StringProperty     drStateA = new SimpleStringProperty(this, "drStateA", null);
                public final StringProperty     drStateE = new SimpleStringProperty(this, "drStateE", null);
                public final StringProperty     modeReq = new SimpleStringProperty(this, "modeReq", null);
                public final StringProperty     mode = new SimpleStringProperty(this, "mode", null);
                public final StringProperty     selState = new SimpleStringProperty(this, "selState", null);
                public final StringProperty     funcState = new SimpleStringProperty(this, "funcState", null);
                public final StringProperty     ntp = new SimpleStringProperty(this, "ntp", null);
                public final StringProperty     timeReq = new SimpleStringProperty(this, "timeReq", null);
                public final StringProperty       posReqA = new SimpleStringProperty(this, "posReqA", null);
                public final StringProperty       posDesA = new SimpleStringProperty(this, "posDesA", null);
                public final StringProperty       posActA = new SimpleStringProperty(this, "posActA", null);
                public final StringProperty       posReqE = new SimpleStringProperty(this, "posReqE", null);
                public final StringProperty       posDesE = new SimpleStringProperty(this, "posDesE", null);
                public final StringProperty       posActE = new SimpleStringProperty(this, "posActE", null);
                public final StringProperty       mVelA = new SimpleStringProperty(this, "mVelA", null);
                public final StringProperty       mReqA = new SimpleStringProperty(this, "mReqA", null);
                public final StringProperty       mVelE = new SimpleStringProperty(this, "mVelE", null);
                public final StringProperty       mReqE = new SimpleStringProperty(this, "mReqE", null);
                public final StringProperty       mTorqA = new SimpleStringProperty(this, "mTorqA", null);
                public final StringProperty       mTorqE = new SimpleStringProperty(this, "mTorqE", null);
                public final StringProperty       mPosA = new SimpleStringProperty(this, "mPosA", null);
                public final StringProperty       mPosE = new SimpleStringProperty(this, "mPosE", null);
                public final StringProperty       supply5V = new SimpleStringProperty(this, "supply5V", null);
                public final StringProperty       dcBusA = new SimpleStringProperty(this, "dcBusA", null);
                public final StringProperty       dcBusE = new SimpleStringProperty(this, "dcBusE", null);
                public final StringProperty       debug0 = new SimpleStringProperty(this, "debug0", null);
                public final StringProperty       debug1 = new SimpleStringProperty(this, "debug1", null);
                public final StringProperty       debug2 = new SimpleStringProperty(this, "debug2", null);
                public final StringProperty       debug3 = new SimpleStringProperty(this, "debug3", null);
                public final StringProperty       debug4 = new SimpleStringProperty(this, "debug4", null);
                public final StringProperty       ctrl1A = new SimpleStringProperty(this, "ctrl1A", null);
                public final StringProperty       ctrl1E = new SimpleStringProperty(this, "ctrl1E", null);
                public final StringProperty       ctrl2A = new SimpleStringProperty(this, "ctrl2A", null);
                public final StringProperty       ctrl2E = new SimpleStringProperty(this, "ctrl2E", null);
                public final StringProperty       ctrl3A = new SimpleStringProperty(this, "ctrl3A", null);
                public final StringProperty       ctrl3E = new SimpleStringProperty(this, "ctrl3E", null);
                public final StringProperty       ctrl4A = new SimpleStringProperty(this, "ctrl4A", null);
                public final StringProperty       ctrl4E = new SimpleStringProperty(this, "ctrl4E", null);
                public final StringProperty       ctrl5A = new SimpleStringProperty(this, "ctrl5A", null);
                public final StringProperty       ctrl5E = new SimpleStringProperty(this, "ctrl5E", null);
                
               // private final ObservableList<Property<Number>> values = FXCollections.observableArrayList();

    
    public logEntry () {
        this(null, null, null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null);
    }
    
    
    public logEntry(String time, String upSlow, String upFast, String dnSlow, String dnFast, String rtSlow, String rtFast, String ltSlow, String ltFast, String feedAcc, String stow, String remote, String local, String VtripE380, String brkRoffE, String VonE24, String Voff380, String VtripA380, String brkRoffA, String VonA24, String Von24, String overHlim, String tBoxOver, String notEstop, String overlap1, String enReqE, String enE, String topHlim, String botHlim, String notTopFlim, String notBotFlim, String bkStow, String brakeE, String enReqA, String enA, String rtHlim, String ltHlim, String notRtFlim, String notLtFlim, String overlap2, String brakeA, String drStateA, String drStateE, String modeReq, String mode, String selState, String funcState, String ntp, String timeReq, String posReqA, String posDesA, String posActA, String posReqE, String posDesE, String posActE, String mVelA, String mReqA, String mVelE, String mReqE, String mTorqA, String mTorqE, String mPosA, String mPosE, String supply5V, String dcBusA, String dcBusE, String debug0, String debug1, String debug2, String debug3, String debug4, String ctrl1A, String ctrl1E, String ctrl2A, String ctrl2E, String ctrl3A, String ctrl3E, String ctrl4A, String ctrl4E, String ctrl5A, String ctrl5E) {
        this.time.set(time);
        this.upSlow.set(upSlow);
        this.upFast.set(upFast);
        this.dnSlow.set(dnSlow);
        this.dnFast.set(dnFast);
        this.rtSlow.set(rtSlow);
        this.rtFast.set(rtFast);
        this.ltSlow.set(ltSlow);
        this.ltFast.set(ltFast);
        this.feedAcc.set(feedAcc);
        this.stow.set(stow);
        this.remote.set(remote);
        this.local.set(local);
        this.VtripE380.set(VtripE380);
        this.brkRoffE.set(brkRoffE);
        this.VonE24.set(VonE24);
        this.Voff380.set(Voff380);
        this.VtripA380.set(VtripA380);
        this.brkRoffA.set(brkRoffA);
        this.VonA24.set(VonA24);
        this.Von24.set(Von24);
        this.overHlim.set(overHlim);
        this.tBoxOver.set(tBoxOver);
        this.notEstop.set(notEstop);
        this.overlap1.set(overlap1);
        this.enReqE.set(enReqE);
        this.enE.set(enE);
        this.topHlim.set(topHlim);
        this.botHlim.set(botHlim);
        this.notTopFlim.set(notTopFlim);
        this.notBotFlim.set(notBotFlim);
        this.bkStow.set(bkStow);
        this.brakeE.set(brakeE);
        this.enReqA.set(enReqA);
        this.enA.set(enA);
        this.rtHlim.set(rtHlim);
        this.ltHlim.set(ltHlim);
        this.notRtFlim.set(notRtFlim);
        this.notLtFlim.set(notLtFlim);
        this.overlap2.set(overlap2);
        this.brakeA.set(brakeA);
        this.drStateA.set(drStateA);
        this.drStateE.set(drStateE);
        this.modeReq.set(modeReq);
        this.mode.set(mode);
        this.selState.set(selState);
        this.funcState.set(funcState);
        this.ntp.set(ntp);
        this.timeReq.set(timeReq);
        this.posReqA.set(posReqA);
        this.posDesA.set(posDesA);
        this.posActA.set(posActA);
        this.posReqE.set(posReqE);
        this.posDesE.set(posDesE);
        this.posActE.set(posActE);
        this.mVelA.set(mVelA);
        this.mReqA.set(mReqA);
        this.mVelE.set(mVelE);
        this.mReqE.set(mReqE);
        this.mTorqA.set(mTorqA);
        this.mTorqE.set(mTorqE);
        this.mPosA.set(mPosA);
        this.mPosE.set(mPosE);
        this.supply5V.set(supply5V);
        this.dcBusA.set(dcBusA);
        this.dcBusE.set(dcBusE);
        this.debug0.set(debug0);
        this.debug1.set(debug1);
        this.debug2.set(debug2);
        this.debug3.set(debug3);
        this.debug4.set(debug4);
        this.ctrl1A.set(ctrl1A);
        this.ctrl1E.set(ctrl1E);
        this.ctrl2A.set(ctrl2A);
        this.ctrl2E.set(ctrl2E);
        this.ctrl3A.set(ctrl3A);
        this.ctrl3E.set(ctrl3E);
        this.ctrl4A.set(ctrl4A);
        this.ctrl4E.set(ctrl4E);
        this.ctrl5A.set(ctrl5A);
        this.ctrl5E.set(ctrl5E);
    }
    public final String getTime() {
        return time.get();
    }
    public final void setTime(String time) {//1
    timeProperty().set(time);
    }
    public final StringProperty timeProperty() {//1
    return time;
    }

  

    public final String getUpSlow() {
        return upSlow.get();
    }
    public final void setUpSlow(String upSlow) {//1
    upSlowProperty().set(upSlow);
    }
    public final StringProperty upSlowProperty() {//1
    return upSlow;
    }

    public String getUpFast() {
        return upFast.get();
    }

    public String getDnSlow() {
        return dnSlow.get();
    }

    public String getDnFast() {
        return dnFast.get();
    }

    public String getRtSlow() {
        return rtSlow.get();
    }

    public String getRtFast() {
        return rtFast.get();
    }

    public String getLtSlow() {
        return ltSlow.get();
    }

    public String getLtFast() {
        return ltFast.get();
    }

    public String getFeedAcc() {
        return feedAcc.get();
    }

    public String getStow() {
        return stow.get();
    }

    public String getRemote() {
        return remote.get();
    }

    public String getLocal() {
        return local.get();
    }

    public String getVtripE380() {
        return VtripE380.get();
    }

    public String getBrkRoffE() {
        return brkRoffE.get();
    }

    public String getVonE24() {
        return VonE24.get();
    }

    public String getVoff380() {
        return Voff380.get();
    }

    public String getVtripA380() {
        return VtripA380.get();
    }

    public String getBrkRoffA() {
        return brkRoffA.get();
    }

    public String getVonA24() {
        return VonA24.get();
    }

    public String getVon24() {
        return Von24.get();
    }

    public String getOverHlim() {
        return overHlim.get();
    }

    public String getTBoxOver() {
        return tBoxOver.get();
    }

    public String getNotEstop() {
        return notEstop.get();
    }

    public String getOverlap1() {
        return overlap1.get();
    }

    public String getEnReqE() {
        return enReqE.get();
    }

    public String getEnE() {
        return enE.get();
    }

    public String getTopHlim() {
        return topHlim.get();
    }

    public String getBotHlim() {
        return botHlim.get();
    }

    public String getNotTopFlim() {
        return notTopFlim.get();
    }

    public String getNotBotFlim() {
        return notBotFlim.get();
    }

    public String getBkStow() {
        return bkStow.get();
    }

    public String getBrakeE() {
        return brakeE.get();
    }

    public String getEnReqA() {
        return enReqA.get();
    }

    public String getEnA() {
        return enA.get();
    }

    public String getRtHlim() {
        return rtHlim.get();
    }

    public String getLtHlim() {
        return ltHlim.get();
    }

    public String getNotRtFlim() {
        return notRtFlim.get();
    }

    public String getNotLtFlim() {
        return notLtFlim.get();
    }

    public String getOverlap2() {
        return overlap2.get();
    }

    public String getBrakeA() {
        return brakeA.get();
    }

    public String getDrStateA() {
        return drStateA.get();
    }

    public String getDrStateE() {
        return drStateE.get();
    }

    public String getModeReq() {
        return modeReq.get();
    }

    public String getMode() {
        return mode.get();
    }

    public String getSelState() {
        return selState.get();
    }

    public String getFuncState() {
        return funcState.get();
    }

    public String getNtp() {
        return ntp.get();
    }

    public String getTimeReq() {
        return timeReq.get();
    }

    public String getPosReqA() {
        return posReqA.get();
    }

    public String getPosDesA() {
        return posDesA.get();
    }

    public String getPosActA() {
        return posActA.get();
    }

    public String getPosReqE() {
        return posReqE.get();
    }

    public String getPosDesE() {
        return posDesE.get();
    }

    public String getPosActE() {
        return posActE.get();
    }

    public String getMVelA() {
        return mVelA.get();
    }

    public String getMReqA() {
        return mReqA.get();
    }

    public String getMVelE() {
        return mVelE.get();
    }

    public String getMReqE() {
        return mReqE.get();
    }

    public String getMTorqA() {
        return mTorqA.get();
    }

    public String getMTorqE() {
        return mTorqE.get();
    }

    public String getMPosA() {
        return mPosA.get();
    }

    public String getMPosE() {
        return mPosE.get();
    }

    public String getSupply5V() {
        return supply5V.get();
    }

    public String getDcBusA() {
        return dcBusA.get();
    }

    public String getDcBusE() {
        return dcBusE.get();
    }

    public String getDebug0() {
        return debug0.get();
    }

    public String getDebug1() {
        return debug1.get();
    }

    public String getDebug2() {
        return debug2.get();
    }

    public String getDebug3() {
        return debug3.get();
    }

    public String getDebug4() {
        return debug4.get();
    }

    public String getCtrl1A() {
        return ctrl1A.get();
    }

    public String getCtrl1E() {
        return ctrl1E.get();
    }

    public String getCtrl2A() {
        return ctrl2A.get();
    }

    public String getCtrl2E() {
        return ctrl2E.get();
    }

        public String getCtrl3A() {
        return ctrl3A.get();
    }

    public String getCtrl3E() {
        return ctrl3E.get();
    }

    public String getCtrl4A() {
        return ctrl4A.get();
    }

    public String getCtrl4E() {
        return ctrl4E.get();
    }

    public String getCtrl5A() {
        return ctrl5A.get();
    }

    public String getCtrl5E() {
        return ctrl5E.get();
    }
            

//
//    logEntry(String tim, String upSlo, String upFas, String dnSlo, String dnFas, String rtSlo, String rtFas, String ltSlo, String ltFas, String feedAc, String sto, String remot, String loca, String VtripE38, String brkRoff, String VonE2, String Voff38, String VtripA38, String brkRof, String VonA2, String Von2, String overHli, String tBoxOve, String notEsto, String overla1, String enReq, String en, String topHli, String botHli, String notTopFli, String notBotFli, String bkSto, String brake, String enReq1, String enA1, String rtHli, String ltHli, String notRtFli, String notLtFli, String overla2, String brakA, String drStatA, String drStatE, String modeRq, String moe, String selStae, String funcStae, String np, String timeRq, String posReA, String posDeA, String posAcA, String posReE, String posDeE, String posAcE, String mVeA, String mReA, String mVeE, String mReE, String mTorA, String mTorE, String mPoA, String mPoE, String suppl5V, String dcBuA, String dcBuE, String debu0, String debu1, String debu2, String debu3, String debu4, String ctrl1, String ctrl2, String ctrl3, String ctrl4, String ctrl5, String ctrl6, String ctrl7, String ctrl8, String ctrl9, String ctrl10) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    logEntry(String time, String upSlow, String upFast, String dnSlow, String dnFast, String rtSlow, String rtFast, String ltSlow, String ltFast, String feedAcc, String stow, String remote, String local, int i) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    logEntry(TableColumn<logEntry, Float> ctrl2E, TableColumn<logEntry, Float> ctrl3A, TableColumn<logEntry, Float> ctrl3E, TableColumn<logEntry, Float> ctrl4A, TableColumn<logEntry, Float> ctrl4E, TableColumn<logEntry, Float> ctrl5A, TableColumn<logEntry, Float> ctrl5E) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
//    logEntry(String tim, String upSlo, String upFas, String dnSlo, String dnFas, String rtSlo, String rtFas, String ltSlo, String ltFas, String feedAc, String sto, String remot, String loca, String VtripE38, String brkRoff, String VonE2, String Voff38, String VtripA38, String brkRof, String VonA2, String Von2, String overHli, String tBoxOve, String notEsto, String overla1, String enReq, String en, String topHli, String botHli, String notTopFli, String notBotFli, String bkSto, String brake, String enReq1, String enA1, String rtHli, String ltHli, String notRtFli, String notLtFli, String overla2, String brakA, String drStatA, String drStatE, String modeRq, String moe, String selStae, String funcStae, String np, String timeRq, String posReA, String posDeA, String posAcA, String posReE, String posDeE, String posAcE, String mVeA, String mReA, String mVeE, String mReE, String mTorA, String mTorE, String mPoA, String mPoE, String suppl5V, String dcBuA, String dcBuE, String debu0, String debu1, String debu2, String debu3, String debu4, String ctrl1, String ctrl2, String ctrl3, String ctrl4, String ctrl5, String ctrl6, String ctrl7, String ctrl8, String ctrl9, String ctrl10) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

                
//     firstName = new SimpleStringProperty(this, "firstName", null);
//    private final StringProperty lastName = new SimpleStringProperty(this, "lastName", null);
//    private final StringProperty phoneNumber = new SimpleStringProperty(this, "phoneNumber", null);
//    private final StringProperty firstName = new SimpleStringProperty(this, "firstName", null);
//    private final StringProperty lastName = new SimpleStringProperty(this, "lastName", null);
//    private final StringProperty phoneNumber = new SimpleStringProperty(this, "phoneNumber", null);
//    private final StringProperty firstName = new SimpleStringProperty(this, "firstName", null);
//    private final StringProperty lastName = new SimpleStringProperty(this, "lastName", null);
//    private final StringProperty phoneNumber = new SimpleStringProperty(this, "phoneNumber", null);
//  
            
//public class ChartData {
//private ObservableList<String> series;
//private ObservableList<logEntry> data;
//
//public ChartData(){
//    series = FXCollections.observableArrayList();
//    data = FXCollections.observableArrayList();
//}
//
//public ObservableList<logEntry> getlogEntry(){
//    return data;
//}
//
//public int getlogEntryValuesSize(){
//    return data.get(0).getValues().size();
//}
//
//public void setlogEntry(ObservableList<logEntry> data) {
//    this.data = data;
//}
//
//public void setBindings(){
//
//    ObservableList<logEntry> tempData;
//    tempData = FXCollections.observableArrayList(item -> {
//        Observable[] obs = new Observable[item.getValues().size() + 1];
//        obs[0] = item.nameProperty();
//
//        for(int i = 0; i < item.getValues().size(); i++){
//            obs[i+1] = item.getProperty(i);
//        }
//
//        return obs;
//    });
//
//    tempData.addAll(data);
//    setlogEntry(tempData);
//}
//}
//
//ChartFactory class (only important methods):
//
//    private BarChart createBarChart(ChartData chartData) {
//    final CategoryAxis xAxis = new CategoryAxis();
//    final NumberAxis yAxis = new NumberAxis();
//
//    final BarChart<String, Number> bc =
//            new BarChart<String, Number>(xAxis, yAxis);
//
//    bc.setTitle("Chart Title");
//    xAxis.setLabel("XAxis Label Title");
//    yAxis.setLabel("YAxis Label Title");
//
//    // append Data
//    fillChartWithData(chartData, bc);
//
//    return bc;
//}
//
//    private void fillChartWithData(ChartData chartData, XYChart<String, Number> chart){
//    chartData.setBindings();
//
//    if (chartData.getSeriesSize() != 0)
//        fillChartWithDataSeriesNotEmpty(chartData, chart);
//    else
//        fillChartWithDataSeriesEmpty(chartData, chart);
//}
//
//// ChartSeries not empty, no PieChartData
//private void fillChartWithDataSeriesNotEmpty(ChartData chartData, XYChart<String, Number> chart) {
//    int count = 0;
//
//    for (String series : chartData.getSeries()) {
//        final int finalCount = count;
//
//        ObservableList<XYChart.Data<String, Number>> dataSet1 = EasyBind.map(chartData.getlogEntry(),
//                item -> new XYChart.Data<>(item.getName(), (Number) item.getValue(finalCount)));
//
//        XYChart.Series<String, Number> chartSeries = new XYChart.Series<>(series, dataSet1);
//
//        chart.getData().add(chartSeries);
//        count++;
//    }
//}
//
//// ChartSeries empty, PieChartData
//private void fillChartWithDataSeriesEmpty(ChartData chartData, XYChart<String, Number> chart) {
//   //for (Data data : chartData.getData()) {
//        ObservableList<XYChart.Data<String, Number>> dataSet1 = EasyBind.map(chartData.getlogEntry (),
//                item -> new XYChart.Data<>(item.getName(), (Number) item.getFirstValue()));
//
//        XYChart.Series<String, Number> chartSeries = new XYChart.Series<>(null, dataSet1);
//
//        chart.getData().add(chartSeries);
//   // }
//}
}
