/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;





import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Side;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Separator;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.TableRow;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.Pane;
import javafx.util.Callback;


import java.io.FileOutputStream;
import java.util.Date;

import com.itextpdf.text.Anchor;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chapter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Section;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ProgressIndicator;

//         <?import java.util.ArrayList?>
//import org.javafxdata.datasources.io.FileSource;
//import org.javafxdata.samples.control.support.Utils;


/**
 * 2016 (c) ESC Inc., kasoa, Central Region.
 * Unless required by applicable law or agreed to in writing
 * Software distributed is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY 
 * KIND, either express or implied
 * @author David
 */ 



public class LoginController implements Initializable{
    
    
        @FXML
        AnchorPane anchorpane4;
                
        @FXML        
        BorderPane borderpane1;
        
               
        
        
        @FXML        
        Button  upslowchart,upfastchart,dnSlowchart,dnFastchart,rtSlowchart, rtFastchart,ltSlowchart,
                ltFastchart, feedAccchart,stowchart,remotechart,localchart,
                VtripE380chart,brkRoffEchart,VonE24chart,Voff380chart,
                VtripA380chart,brkRoffAchart,VonA24chart,Von24chart,
                overHlimchart,tBoxOverchart,notEstopchart,overlap1chart,
                enReqEchart,enEchart,topHlimchart,botHlimchart,notTopFlimchart,
                notBotFlimchart,bkStowchart,brakeEchart, enReqAchart,enAchart,
                rtHlimchart,ltHlimchart,notRtFlimchart,notLtFlimchart,overlap2chart,
                brakeAchart, drStateAchart,drStateEchart,modeReqchart,modechart,selStatechart,
                funcStatechart,ntpchart, timeReqchart,posReqAchart,posDesAchart,posActAchart,
                posReqEchart,posDesEchart,posActEchart, mVelAchart,mReqAchart,mVelEchart,
                mReqEchart,mTorqAchart,mTorqEchart,mPosAchart,mPosEchart, supply5Vchart,
                dcBusAchart,dcBusEchart, debug0chart,debug1chart,debug2chart,debug3chart,
                debug4chart, ctrl1Achart,ctrl1Echart,ctrl2Achart,ctrl2Echart,ctrl3Achart,
                ctrl3Echart,ctrl4Achart,ctrl4Echart,ctrl5Achart,ctrl5Echart;
        
        
        
        
        @FXML
        public List<Button> ButtonList;
        
        
        
        @FXML
        Tooltip upslowtooltip,upfasttooltip, dnSlowtooltip,dnFasttooltip,rtSlowtooltip,rtFasttooltip,ltSlowtooltip,ltFasttooltip,feedAcctooltip,
                stowtooltip,remotetooltip,localtooltip,VtripE380tooltip,brkRoffEtooltip,VonE24tooltip,Voff380tooltip,VtripA380tooltip,
                brkRoffAtooltip,VonA24tooltip,Von24tooltip,overHlimtooltip,tBoxOvertooltip,notEstoptooltip,overlap1tooltip,enReqEtooltip,
                enEtooltip,topHlimtooltip,botHlimtooltip,notTopFlimtooltip,notBotFlimtooltip,bkStowtooltip,
                brakeEtooltip,enReqAtooltip,enAtooltip,rtHlimtooltip,ltHlimtooltip,notRtFlimtooltip,notLtFlimtooltip,overlap2tooltip,brakeAtooltip,
                drStateAtooltip,drStateEtooltip,modeReqtooltip,modetooltip,selStatetooltip,funcStatetooltip,ntptooltip,timeReqtooltip,
                posReqAtooltip,posDesAtooltip,posActAtooltip,posReqEtooltip,posDesEtooltip,posActEtooltip,
                mVelAtooltip,mReqAtooltip,mVelEtooltip,mReqEtooltip,mTorqAtooltip,mTorqEtooltip,mPosAtooltip,mPosEtooltip,supply5Vtooltip,
                dcBusAtooltip,dcBusEtooltip,debug0tooltip,debug1tooltip,debug2tooltip,debug3tooltip,debug4tooltip,ctrl1Atooltip,ctrl1Etooltip,
                ctrl2Atooltip,ctrl2Etooltip,ctrl3Atooltip,ctrl3Etooltip,ctrl4Atooltip,ctrl4Etooltip,ctrl5Atooltip,ctrl5Etooltip,loadtooltip,
                newfiletooltip,closetooltip,abouttooltip,customizetooltip,previoustooltip,forwardtooltip,exittooltip,dirtooltip,cleartooltip;

               
        
        @FXML        
        Button load;
        
        
        @FXML        
        Button newfile;
        
        
        @FXML        
        Button close;
        
        
        @FXML        
        Button previous;
        
        
        @FXML        
        Button previous1;
        
        
        @FXML        
        Button forward;
        
        
        
        
        @FXML        
        Button about;
        
        
        @FXML        
        Button customize;
        
        @FXML        
        Button closevbox, vboxback1, vboxback2, vboxback3, vboxback4, vboxback5, vboxback6, vboxback7, vboxback8;
        
        
        @FXML        
        Button exit;
        
        
        @FXML        
        Button onetoten, eleven, twentyone, thirtyone,fourtyone, fiftyone, sixtyone, seventyone;
        
        
        @FXML        
        AnchorPane anchorpane;
        
        
        @FXML        
        AnchorPane vcharts;
                
        @FXML        
        Label tableview;
        
        @FXML
        Separator separator2;

        @FXML        
        Button viewchart;
                
        @FXML        
        ScrollPane scrollpane3;
                
        @FXML        
        AnchorPane anchorpane3;
                
        @FXML        
        Separator seperator1;
                
        @FXML        
        Label radiotelescope;
        
        
        @FXML        
        Pane stats;
        
        
        @FXML        
        Pane brief, chartpane;
        
                
                
        @FXML        
        ScrollPane scrollpane1;
                
        @FXML        
        AnchorPane anchorpane1;
                
        @FXML        
        ScrollPane scrollpane2;
                
        @FXML
        AnchorPane anchorpane2;
                
        @FXML        
        Label positioninformation;
        
        @FXML        
        Label at;
                
        @FXML        
        Label on;
        
        @FXML        
        CheckBox timeCB,upSlowCB,upFastCB,dnSlowCB,dnFastCB,rtSlowCB, rtFastCB,ltSlowCB,ltFastCB, feedAccCB,stowCB,
                 remoteCB,localCB, VtripE380CB,brkRoffECB,VonE24CB,Voff380CB,VtripA380CB,brkRoffACB,VonA24CB,
                 Von24CB, overHlimCB,tBoxOverCB,notEstopCB,overlap1CB, enReqECB,enECB,topHlimCB,botHlimCB,
                 notTopFlimCB,notBotFlimCB,bkStowCB,brakeECB, enReqACB,enACB,rtHlimCB,ltHlimCB,notRtFlimCB,
                 notLtFlimCB,overlap2CB,brakeACB, drStateACB,drStateECB,modeReqCB,modeCB,selStateCB,funcStateCB,
                 ntpCB, timeReqCB,posReqACB,posDesACB,posActACB,posReqECB,posDesECB,posActECB, mVelACB,mReqACB,
                 mVelECB,mReqECB,mTorqACB,mTorqECB,mPosACB,mPosECB, supply5VCB, dcBusACB,dcBusECB, debug0CB,debug1CB,
                 debug2CB,debug3CB,debug4CB, ctrl1ACB,ctrl1ECB,ctrl2ACB,ctrl2ECB,ctrl3ACB,ctrl3ECB,ctrl4ACB,ctrl4ECB,ctrl5ACB,ctrl5ECB;
        
        
        @FXML        
        TextField onText, selected;
        
        
        @FXML        
        TextField size;
        
        
        @FXML        
        TextArea textarea;
                
        @FXML        
        ComboBox combo1;
                
        @FXML        
        ComboBox combox2;
        
        @FXML        
        Label speeddetails;
                
        @FXML        
        RadioButton seedetailspdf;
        
        @FXML        
        Button next;
                
        @FXML        
        Button clear;
        
        @FXML        
        Button dir;
        
                
        @FXML        
        private Label processingcommand;
        
        @FXML private VBox vbxDir, vbox1, vbox2, vbox3, vbox4, vbox5, vbox6, vbox7, vbox8;
        
        @FXML
        ProgressIndicator pi = new ProgressIndicator();
        
        @FXML private TabPane maintabpane;
        
        
        @FXML private Tab ltSlowFast;
        
        @FXML private Tab dnS;
        
        @FXML private Tab filetab;
        
        
        @FXML private Tab rtSlowFast;
        
        @FXML private Tab dnSlowFast;
        
        @FXML 
        AnchorPane ac;  
        

        
        @FXML
        private NumberAxis xAxis = new NumberAxis();
        
        @FXML
        final NumberAxis yAxis = new NumberAxis();
        
         @FXML
         LineChart<Number, Number> lc ;//= new LineChart<Number, Number>(xAxis, yAxis);
        
         
         @FXML
         final LineChart<Number, Number> lc1 = new LineChart<Number, Number>(xAxis, yAxis);
        
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
            table.setPlaceholder(new Label("Select Help then Click Directions or Alt + L to Load Data"));
            Image image1 = new Image(getClass().getResourceAsStream("page_white_go.png"));
            load.setGraphic(new ImageView(image1));
            
            Image image2 = new Image(getClass().getResourceAsStream("cross.png"));
            exit.setGraphic(new ImageView(image2));
            
            //upfastchart,dnSlowchart,dnFastchart,rtSlowchart, rtFastchart,ltSlowchart,
                             
            Image image3 = new Image(getClass().getResourceAsStream("cancel.png"));
            closevbox.setGraphic(new ImageView(image3));
            
                             
            Image image4 = new Image(getClass().getResourceAsStream("page_add.png"));
            newfile.setGraphic(new ImageView(image4));
            
                             
            
            Image image5 = new Image(getClass().getResourceAsStream("application_form_delete.png"));
            close.setGraphic(new ImageView(image5));
            
                             
            
            Image image6 = new Image(getClass().getResourceAsStream("application_form_edit.png"));
            customize.setGraphic(new ImageView(image6));
            
                             
            
            Image image7 = new Image(getClass().getResourceAsStream("table_delete.png"));
            clear.setGraphic(new ImageView(image7));
            
            
            Image image8 = new Image(getClass().getResourceAsStream("arrow_left.png"));
            previous1.setGraphic(new ImageView(image8));
            
            Image image9 = new Image(getClass().getResourceAsStream("arrow_right.png"));
            forward.setGraphic(new ImageView(image9));
            
            Image image10 = new Image(getClass().getResourceAsStream("page_white_acrobat.png"));
            dir.setGraphic(new ImageView(image10));
            
            Image image11 = new Image(getClass().getResourceAsStream("help.png"));
            about.setGraphic(new ImageView(image11));
            
            vbox1.setVisible(false);
            vbox2.setVisible(false);
            vbox3.setVisible(false);
            vbox4.setVisible(false);
            vbox5.setVisible(false);
            vbox6.setVisible(false);
            vbox7.setVisible(false);
            vbox8.setVisible(false);
            
            
                            try {
                        
                      //  PdfWriter.getInstance(document, new FileOutputStream(FILE));
                        
                       
//                        addMetaData(document);
//                        addTitlePage(document);
//                        addContent(document);
                       
                } catch (Exception e) {
                        e.printStackTrace();
                }
            
            
            pi.setVisible(false);
            
            
            

           setRowFactory();
           
           
           
     
    }
    
    
        
        
        
    @FXML private AnchorPane apCSV;
    @FXML private ScrollPane scrollpane;
    @FXML private Button wide;
            
 

    @FXML public TableView<logEntry> table = new TableView<>();
    @FXML public TableColumn <logEntry, Integer>    time;
    @FXML public TableColumn <logEntry,String>     upSlow;
    @FXML public TableColumn <logEntry,String>     upFast;
    @FXML public TableColumn <logEntry,String>     dnSlow;
    @FXML public TableColumn <logEntry, String>    dnFast;
    @FXML public TableColumn <logEntry, String>    rtSlow;
    @FXML public TableColumn <logEntry, String>    rtFast;
    @FXML public TableColumn <logEntry, String>    ltSlow;
    @FXML public TableColumn <logEntry, String>    ltFast;
    @FXML public TableColumn <logEntry, String>    feedAcc;
    @FXML public TableColumn <logEntry, String>    stow;
    @FXML public TableColumn <logEntry, String>    remote;
    @FXML public TableColumn <logEntry, String>    local;
    @FXML public TableColumn <logEntry, String>    VtripE380;
    @FXML public TableColumn <logEntry, String>    brkRoffE;
    @FXML public TableColumn <logEntry, String>    VonE24;
    @FXML public TableColumn <logEntry, String>    Voff380;
    @FXML public TableColumn <logEntry, String>    VtripA380;
    @FXML public TableColumn <logEntry, String>    brkRoffA;
    @FXML public TableColumn <logEntry, String>    VonA24;
    @FXML public TableColumn <logEntry, String>    Von24;
    @FXML public TableColumn <logEntry, String>    overHlim;
    @FXML public TableColumn <logEntry, String>    tBoxOver;
    @FXML public TableColumn <logEntry, String>    notEstop;
    @FXML public TableColumn <logEntry, String>    overlap1;
    @FXML public TableColumn <logEntry, String>    enReqE;
    @FXML public TableColumn <logEntry, String>    enE;
    @FXML public TableColumn <logEntry, String>    topHlim;
    @FXML public TableColumn <logEntry, String>    botHlim;
    @FXML public TableColumn <logEntry, String>    notTopFlim;
    @FXML public TableColumn <logEntry, String>    notBotFlim;
    @FXML public TableColumn <logEntry, String>    bkStow;
    @FXML public TableColumn <logEntry, String>    brakeE;
    @FXML public TableColumn <logEntry, String>    enReqA;
    @FXML public TableColumn <logEntry, String>    enA;
    @FXML public TableColumn <logEntry, String>    rtHlim;
    @FXML public TableColumn <logEntry, String>    ltHlim;
    @FXML public TableColumn <logEntry, String>    notRtFlim;
    @FXML public TableColumn <logEntry, String>    notLtFlim;
    @FXML public TableColumn <logEntry, String>    overlap2;
    @FXML public TableColumn <logEntry, String>    brakeA;
    @FXML public TableColumn <logEntry, String>    drStateA;
    @FXML public TableColumn <logEntry, String>    drStateE;
    @FXML public TableColumn <logEntry, String>    modeReq;
    @FXML public TableColumn <logEntry, String>    mode;
    @FXML public TableColumn <logEntry, String>    selState;
    @FXML public TableColumn <logEntry, String>    funcState;
    @FXML public TableColumn <logEntry, String>    ntp;
    @FXML public TableColumn <logEntry, String>    timeReq;
    @FXML public TableColumn <logEntry, String>    posReqA;
    @FXML public TableColumn <logEntry, String>    posDesA;
    @FXML public TableColumn <logEntry, String>    posActA;
    @FXML public TableColumn <logEntry, String>    posReqE;
    @FXML public TableColumn <logEntry, String>    posDesE;
    @FXML public TableColumn <logEntry, String>    posActE;
    @FXML public TableColumn <logEntry, String>    mVelA;
    @FXML public TableColumn <logEntry, String>    mReqA;
    @FXML public TableColumn <logEntry, String>    mVelE;
    @FXML public TableColumn <logEntry, String>    mReqE;
    @FXML public TableColumn <logEntry, String>    mTorqA;
    @FXML public TableColumn <logEntry, String>    mTorqE;
    @FXML public TableColumn <logEntry, String>    mPosA;
    @FXML public TableColumn <logEntry, String>    mPosE;
    @FXML public TableColumn <logEntry, String>    supply5V;
    @FXML public TableColumn <logEntry, String>    dcBusA;
    @FXML public TableColumn <logEntry, String>    dcBusE;
    @FXML public TableColumn <logEntry, String>    debug0;
    @FXML public TableColumn <logEntry, String>    debug1;
    @FXML public TableColumn <logEntry, String>    debug2;
    @FXML public TableColumn <logEntry, String>    debug3;
    @FXML public TableColumn <logEntry, String>    debug4;
    @FXML public TableColumn <logEntry, String>    ctrl1A;
    @FXML public TableColumn <logEntry, String>    ctrl1E;
    @FXML public TableColumn <logEntry, String>    ctrl2A;
    @FXML public TableColumn <logEntry, String>    ctrl2E;
    @FXML public TableColumn <logEntry, String>    ctrl3A;
    @FXML public TableColumn <logEntry, String>    ctrl3E;
    @FXML public TableColumn <logEntry, String>    ctrl4A;
    @FXML public TableColumn <logEntry, String>    ctrl4E;
    @FXML public TableColumn <logEntry, String>    ctrl5A;
    @FXML public TableColumn <logEntry, String>    ctrl5E;
    
    
    public void setRowFactory(){
     table.setRowFactory( new Callback<TableView<logEntry>, TableRow<logEntry>>() {
            @Override
           public TableRow<logEntry> call(TableView <logEntry> p) {
         
     
          final TableRow <logEntry>  row = new TableRow <logEntry> ();
          row.setOnScrollStarted(new EventHandler <ScrollEvent> () {
              @Override
              public void handle(ScrollEvent t){
                onText.setText(String.valueOf(table.getSelectionModel().getSelectedIndex() + 1 ) );  
              }
          });
          row.setOnMouseClicked(event ->  {
              if (event.getClickCount()== 1 && (!row.isEmpty())) {
                  onText.setText(String.valueOf(table.getSelectionModel().getSelectedIndex() + 1 ) );
            on.setText("Record") ;
            at.setText("of");
           int best = data.size();
           size.setText(Integer.toString(best));
           size.setEditable(false);
                  
              }
           
          
          });
          
           return row;
     }
     });
     
    }      
    
   
           Anchor anchor = new Anchor("First Chapter", catFont);
               

                // Second parameter is the number of the chapter
                Chapter catPart = new Chapter(new Paragraph(anchor), 1);

                Paragraph subPara = new Paragraph("Subcategory 1", subFont);
                Section subCatPart = catPart.addSection(subPara);
//                subCatPart.add(new Paragraph("Hello"));

//                subPara = new Paragraph("Subcategory 2", subFont);
               
    
    
            
                String  [] methodNames = {"upSlowChart","UpFastChart","dnSlowChart","dnFastChart","rtSlowChart","rtFastChart",
                                            "ltSlowChart","ltFastchart","feedAccchart","stowchart","remotechart","localchart",
                                            "VtripE380chart","brkRoffEchart","VonE24chart","Voff380chart","VtripA380chart",
                                            "brkRoffAchart","VonA24chart","Von24chart","overHlimchart","tBoxOverchart",
                                            "notEstopchart","overlap1chart","enReqEchart","enEchart","topHlimchart","botHlimchart","notTopFlimchart",
                                            "notBotFlimchart","bkStowchart","brakeEchart","enReqAchart","enAchart","rtHlimchart","ltHlimchart",
                                            "notRtFlimchart","notLtFlimchart","overlap2chart","brakeAchart","drStateAchart","drStateEchart","modeReqchart",
                                            "modechart","selStatechart","funcStatechart","ntpchart","posReqAchart","timeReqchart","posDesAchart",
                                            "posActAchart","posReqEchart","posDesEchart","posActEchart","mVelAchart","mReqAchart","mVelEchart","mReqEchart",
                                            "mTorqAchart","mTorqEchart","mPosAchart","mPosEchart","supply5Vchart",
                                            "dcBusAchart","dcBusEchart","debug0chart","debug1chart","debug2chart","debug3chart",
                                            "debug4chart","ctrl1Achart","ctrl1Echart","ctrl2Achart","ctrl2Echart","ctrl3Achart",
                                            "ctrl3Echart","ctrl4Achart","ctrl4Echart","ctrl5Achart","ctrl5Echart"};
 
    
     public   final CategoryAxis xAxiss = new CategoryAxis();
     public   final NumberAxis yAxiss = new NumberAxis();
              
     public   final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);
    
      public  XYChart.Series series = new XYChart.Series();
    
        private static String FILE = "c:/Users/"+System.getProperty("user.name")+"/desktop/AstroReaderSummary.pdf";
        private static Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 18,
                        Font.BOLD);
        private static Font redFont = new Font(Font.FontFamily.TIMES_ROMAN, 12,
                        Font.NORMAL, BaseColor.RED);
        private static Font subFont = new Font(Font.FontFamily.TIMES_ROMAN, 16,
                        Font.BOLD);
        private static Font smallBold = new Font(Font.FontFamily.TIMES_ROMAN, 12,
                        Font.BOLD);
    
            private static void addMetaData(Document document) {
                document.addTitle("PDF");
                document.addSubject("events");
                document.addKeywords("Log, Data, Summary");
                document.addAuthor("AstroReader");
                document.addCreator("ESC");
        }
            
            private static void addTitlePage(Document document)
                        throws DocumentException {
                Paragraph preface = new Paragraph();
                // We add one empty line
                addEmptyLine(preface, 1);
                // Lets write a big header
                preface.add(new Paragraph("PDF", catFont));
                preface.setAlignment(Element.ALIGN_CENTER);

                addEmptyLine(preface, 1);
                // Will create: Report generated by: _name, _date
                preface.add(new Paragraph(
                                "Generated by: " + System.getProperty("user.name") + ", " + new Date(), //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                                smallBold));
                addEmptyLine(preface, 1);
                preface.add(new Paragraph(
                                "This document describes something which is very important ",
                                smallBold));
                

                addEmptyLine(preface, 2);

                preface.add(new Paragraph(
                                "This document is a preliminary version and not subject to license agreement or any other agreement with ESC ;-).",
                                redFont));

                document.add(preface);
                // Start a new page
                document.newPage();
        }

            
             private  void addContent(Document document) throws DocumentException {
//                Anchor anchor = new Anchor("First Chapter", catFont);
//                anchor.setName("First Chapter");
//
//                // Second parameter is the number of the chapter
//                Chapter catPart = new Chapter(new Paragraph(anchor), 1);
//
//                Paragraph subPara = new Paragraph("Subcategory 1", subFont);
//                Section subCatPart = catPart.addSection(subPara);
////                subCatPart.add(new Paragraph("Hello"));
//
////                subPara = new Paragraph("Subcategory 2", subFont);
//                subCatPart = catPart.addSection(subPara);
//                subCatPart.add(new Paragraph("Paragraph 1"));
//                subCatPart.add(new Paragraph("Paragraph 2"));
//                subCatPart.add(new Paragraph("Paragraph 3"));

                // add a list
                createList(subCatPart);
                Paragraph paragraph = new Paragraph();
                addEmptyLine(paragraph, 5);
                subCatPart.add(paragraph);

                // add a table
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);

                // now add all this to the document
                document.add(catPart);

                // Next section
                anchor = new Anchor("Second Chapter", catFont);
                anchor.setName("Second Chapter");

                // Second parameter is the number of the chapter
                catPart = new Chapter(new Paragraph(anchor), 1);

                subPara = new Paragraph("Subcategory", subFont);
                subCatPart = catPart.addSection(subPara);
                subCatPart.add(new Paragraph("This is a very important message"));

                // now add all this to the document
                document.add(catPart);

        }

             public  void createTable(Section subCatPart,String yName, double maxx,double minx, double avg, double mode1, double median)
                        throws BadElementException {
                PdfPTable table = new PdfPTable(6);

                // t.setBorderColor(BaseColor.GRAY);
                // t.setPadding(4);
                // t.setSpacing(4);
                // t.setBorderWidth(1);

                PdfPCell c1 = new PdfPCell(new Phrase("Event"));
                c1.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(c1);

                c1 = new PdfPCell(new Phrase("Min, time"));
                c1.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(c1);

                c1 = new PdfPCell(new Phrase("Avg, time"));
                c1.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(c1);
                
                 c1 = new PdfPCell(new Phrase("Median, time"));
                c1.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(c1);
                
                 c1 = new PdfPCell(new Phrase("Max, time"));
                c1.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(c1);
                
                 c1 = new PdfPCell(new Phrase("Mode, time"));
                c1.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(c1);
                
                
                table.setHeaderRows(1);
                table.addCell(yName);
                table.addCell(String.valueOf(minx));
                table.addCell(String.valueOf(avg));
                table.addCell(String.valueOf(median));
                table.addCell(String.valueOf(maxx));
                table.addCell(String.valueOf(mode1));
              
                subCatPart.add(table);

        }
          
   
        private static void createList(Section subCatPart) {
                com.itextpdf.text.List list = new com.itextpdf.text.List(true, false, 10);
                list.add(new ListItem(""));
                list.add(new ListItem(""));
                list.add(new ListItem(""));
                subCatPart.add(list);
        }

        private static void addEmptyLine(Paragraph paragraph, int number) {
                for (int i = 0; i < number; i++) {
                        paragraph.add(new Paragraph(" "));
                }
        }
    
    
    int index = 1;
    class MyList {
         
        ObservableList<logEntry> dataList;
        ObservableList<PieChart.Data> pieChartData1;
        ObservableList<XYChart.Data> xyList2;
         
        MyList(){
            dataList = FXCollections.observableArrayList();
            pieChartData1 = FXCollections.observableArrayList();
            xyList2 = FXCollections.observableArrayList();
        }
         
        public void add(logEntry r){
            dataList.add(r);
            xyList2.add(new XYChart.Data(r.getTime(), r.getUpSlow()));
        }
      }
    
    MyList myList;
    FileChooser fc = new FileChooser();
    public ArrayList<logEntry> list;
    private ListIterator<logEntry> LIT;
    private int i;

    public ObservableList<logEntry> data;
    
    
    @FXML
    private void onetoTen(ActionEvent e) {
        
        vbox1.setVisible(true);
        vbox1.toFront();
    }   
    
    @FXML
    private void onetoTenvboxback(ActionEvent e) {
        vbox1.setVisible(false);
    }
    
    @FXML
    private void eleven(ActionEvent e) {
        
        vbox2.setVisible(true);
        vbox2.toFront();
    }   
    
    @FXML
    private void vboxback2(ActionEvent e) {
        vbox2.setVisible(false);
    }
    
    
    @FXML
    private void twentyone(ActionEvent e) {
        
        vbox3.setVisible(true);
        vbox3.toFront();
    }   
    
    @FXML
    private void vboxback3(ActionEvent e) {
        vbox3.setVisible(false);
    }
    
    
    @FXML
    private void thirtyone(ActionEvent e) {
        
        vbox4.setVisible(true);
        vbox4.toFront();
    }   
    
    @FXML
    private void vboxback4(ActionEvent e) {
        vbox4.setVisible(false);
    }
    
    
    @FXML
    private void fourtyone(ActionEvent e) {
        
        vbox5.setVisible(true);
        vbox5.toFront();
    }   
    
    @FXML
    private void vboxback5(ActionEvent e) {
        vbox5.setVisible(false);
    }
    
    
    @FXML
    private void fiftyone(ActionEvent e) {
        
        vbox6.setVisible(true);
        vbox6.toFront();
    }   
    
    @FXML
    private void vboxback6(ActionEvent e) {
        vbox6.setVisible(false);
    }
    
    
    @FXML
    private void sixtyone(ActionEvent e) {
        
        vbox7.setVisible(true);
        vbox7.toFront();
    }   
    
    @FXML
    private void vboxback7(ActionEvent e) {
        vbox7.setVisible(false);
    }
    
    
    @FXML
    private void seventyone(ActionEvent e) {
        
        vbox8.setVisible(true);
        vbox8.toFront();
    }   
    
    @FXML
    private void vboxback8(ActionEvent e) {
        vbox8.setVisible(false);
    }
    
    
    @FXML
    private void onDir(ActionEvent e) {
        vbxDir.setVisible(true);
        vbxDir.toFront();
    }
    @FXML
    private void onClose(ActionEvent e) {
        vbxDir.setVisible(false);
    }
    
    
    //<?import java.util.ArrayList?> in tableview.fxml
    @FXML
    private void close(ActionEvent e) {
        table.getItems().clear();
        stats.getChildren().clear();
        brief.getChildren().clear();
        dnS.setContent(null);
        dnS.setText("Untitled Tab");
        size.setText(null);
        onText.setText(null);
    }
    
    @FXML
    private void openPDF (ActionEvent e){
                    Document document = new Document();
            try {
                
                try {
                    PdfWriter.getInstance(document, new FileOutputStream(FILE));
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                }
           
                        document.open();
                        addMetaData(document);
                        addTitlePage(document);
                        addContent(document);
                        document.close();
                
            } catch (DocumentException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+"C:\\Users\\"+System.getProperty("user.name")+"\\desktop\\AstroReaderSummary"+".pdf");
            } catch (IOException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
       
    }
    
//    
//    @FXML
//    public void runAnotherApp(Class <? extends Application> lc) throws Exception{
//        Application app2 = lc.newInstance();
//        Stage anotherstage = new Stage();
//        app2.start(anotherstage);
//        
//    }
    
    
    @FXML
    private void exit(ActionEvent e) {
         
         Platform.exit();
         
    }
    
    
    public void changePieColor(
        ObservableList <PieChart.Data> pieChartData, String... pieColors){
        int i = 0;
        
        for(PieChart.Data data: pieChartData) {
            data.getNode().setStyle("-fx-pie-color: " + pieColors[i % pieColors.length] + ";");
            i++;
        }
        
    }
     
    
        @FXML
    private void selectRow(ActionEvent event )
    {   
 
        int row_num = Integer.parseInt(onText.getText()) ;
        //table.getSelectionModel().clearAndSelect(row_num);
            
        table.requestFocus();
        table.getSelectionModel().select(row_num - 1);
        table.getFocusModel().focus(row_num - 1);
        
        
  
    }
    
    @FXML//Load CSV Data
    private void onLoad(ActionEvent e)throws IOException {
        
        
        
     
        
        myList = new MyList();
        
        data = FXCollections.observableArrayList();//Hold data for the table
        



            File file1 = fc.showOpenDialog(null);
            if (file1 == null) {
        return;
        }
            
            pi.setVisible(true);
            pi.toFront();
            
               
            String filename;
            filename = file1.getAbsolutePath();
              String FieldDelimiter = ",";
              
              
              //FileSource = new FileSource(filename);
              //DatasourceReader reader = new FileSource(getClass().getResourceAsStream(filename));
              
            BufferedReader br = new BufferedReader (new FileReader (filename));
            
            String line;
              //read to startLine



            while ( (line = br.readLine()) != null   ) {
                String[]value = line.split(FieldDelimiter);
                        logEntry record = new logEntry(value[0],value[1],value[2],
                        value[3],value[4],value[5],value[6],
                        value[7],value[8],value[9],
                        value[10],value[11],value[12],
                        value[13],value[14],value[15],
                        value[16],value[17],value[18],
                        value[19],value[20],value[21],
                        value[22],value[23],value[24],
                        value[25],value[26],value[27],
                        value[28],value[29],value[30],
                        value[31],value[32],value[33],
                        value[34],value[35],value[36],
                        value[37],value[38],value[39],
                        value[40],value[41],value[42],
                        value[43],value[44],value[45],
                        value[46],value[47],value[48],
                        value[49],value[50],value[51],
                        value[52],value[53],value[54],
                        value[55],value[56],value[57],
                        value[58],value[59],value[60],
                        value[61],value[62],value[63],
                        value[64],value[65],value[66],
                        value[67],value[68],value[69],
                        value[70],value[71],value[72],
                        value[73],value[74],value[75],
                        value[76],value[77],value[78],
                        value[79],value[80]);
                        
           //list.add(record);
           myList.add(record);
           data.add(record);
           table.setItems(data);
           
           
            
           //String best = record.getUpSlow();
}
br.close();
           
           time.setCellValueFactory(new PropertyValueFactory <>("time"));
           upSlow.setCellValueFactory(new PropertyValueFactory <>("upSlow"));
           upFast.setCellValueFactory(new PropertyValueFactory <>("upFast"));
           dnSlow.setCellValueFactory(new PropertyValueFactory <>("dnSlow"));
           dnFast.setCellValueFactory(new PropertyValueFactory <>("dnFast"));
           rtSlow.setCellValueFactory(new PropertyValueFactory <>("rtSlow"));
           rtFast.setCellValueFactory(new PropertyValueFactory <>("rtFast"));
           ltSlow.setCellValueFactory(new PropertyValueFactory <>("ltSlow"));
           ltFast.setCellValueFactory(new PropertyValueFactory <>("ltFast"));
           feedAcc.setCellValueFactory(new PropertyValueFactory <>("feedAcc"));
           stow.setCellValueFactory(new PropertyValueFactory <>("stow"));
           remote.setCellValueFactory(new PropertyValueFactory <>("remote"));
           local.setCellValueFactory(new PropertyValueFactory <>("local"));
           VtripE380.setCellValueFactory(new PropertyValueFactory <>("VtripE380"));
           brkRoffE.setCellValueFactory(new PropertyValueFactory <>("brkRoffE"));
           VonE24.setCellValueFactory(new PropertyValueFactory < >("VonE24"));
           Voff380.setCellValueFactory(new PropertyValueFactory < >("Voff380"));
           VtripA380.setCellValueFactory(new PropertyValueFactory <>("VtripA380"));
           brkRoffA.setCellValueFactory(new PropertyValueFactory <>("brkRoffA"));
           VonA24.setCellValueFactory(new PropertyValueFactory <>("VonA24"));
           Von24.setCellValueFactory(new PropertyValueFactory <>("Von24"));
           overHlim.setCellValueFactory(new PropertyValueFactory <>("overHlim"));
           tBoxOver.setCellValueFactory(new PropertyValueFactory <>("tBoxOver"));
           notEstop.setCellValueFactory(new PropertyValueFactory <>("notEstop"));
           overlap1.setCellValueFactory(new PropertyValueFactory <>("overlap1"));
           enReqE.setCellValueFactory(new PropertyValueFactory <>("enReqE"));
           enE.setCellValueFactory(new PropertyValueFactory <>("enE"));
           topHlim.setCellValueFactory(new PropertyValueFactory <>("topHlim"));
           botHlim.setCellValueFactory(new PropertyValueFactory <>("botHlim"));
           notTopFlim.setCellValueFactory(new PropertyValueFactory <>("notTopFlim"));
           notBotFlim.setCellValueFactory(new PropertyValueFactory <>("notBotFlim"));
           bkStow.setCellValueFactory(new PropertyValueFactory <>("bkStow"));
           brakeE.setCellValueFactory(new PropertyValueFactory <>("brakeE"));
           enReqA.setCellValueFactory(new PropertyValueFactory <>("enReqA"));
           enA.setCellValueFactory(new PropertyValueFactory <>("enA"));
           rtHlim.setCellValueFactory(new PropertyValueFactory <>("rtHlim"));
           ltHlim.setCellValueFactory(new PropertyValueFactory <>("ltHlim"));
           notRtFlim.setCellValueFactory(new PropertyValueFactory <>("notRtFlim"));
           notLtFlim.setCellValueFactory(new PropertyValueFactory <>("notLtFlim"));
           overlap2.setCellValueFactory(new PropertyValueFactory <>("overlap2"));
           brakeA.setCellValueFactory(new PropertyValueFactory <>("brakeA"));
           drStateA.setCellValueFactory(new PropertyValueFactory <>("drStateA"));
           drStateE.setCellValueFactory(new PropertyValueFactory <>("drStateE"));
           modeReq.setCellValueFactory(new PropertyValueFactory <>("modeReq"));
           mode.setCellValueFactory(new PropertyValueFactory <>("mode"));
           selState.setCellValueFactory(new PropertyValueFactory <>("selState"));
           funcState.setCellValueFactory(new PropertyValueFactory <>("funcState"));
           ntp.setCellValueFactory(new PropertyValueFactory <>("ntp"));
           timeReq.setCellValueFactory(new PropertyValueFactory <>("timeReq"));
           posReqA.setCellValueFactory(new PropertyValueFactory <>("posReqA"));
           posDesA.setCellValueFactory(new PropertyValueFactory <>("posDesA"));
           posActA.setCellValueFactory(new PropertyValueFactory <>("posActA"));
           posReqE.setCellValueFactory(new PropertyValueFactory <>("posReqE"));
           posDesE.setCellValueFactory(new PropertyValueFactory <>("posDesE"));
           posActE.setCellValueFactory(new PropertyValueFactory <>("posActE"));
           mVelA.setCellValueFactory(new PropertyValueFactory <>("mVelA"));
           mReqA.setCellValueFactory(new PropertyValueFactory <>("mReqA"));
           mVelE.setCellValueFactory(new PropertyValueFactory <>("mVelE"));
           mReqE.setCellValueFactory(new PropertyValueFactory <>("mReqE"));
           mTorqA.setCellValueFactory(new PropertyValueFactory <>("mTorqA"));
           mTorqE.setCellValueFactory(new PropertyValueFactory <>("mTorqE"));
           mPosA.setCellValueFactory(new PropertyValueFactory <>("mPosA"));
           mPosE.setCellValueFactory(new PropertyValueFactory <>("mPosE"));
           supply5V.setCellValueFactory(new PropertyValueFactory <>("supply5V"));
           dcBusA.setCellValueFactory(new PropertyValueFactory <>("dcBusA"));
          dcBusE.setCellValueFactory(new PropertyValueFactory <>("dcBusE"));
          debug0.setCellValueFactory(new PropertyValueFactory <>("debug0"));
          debug1.setCellValueFactory(new PropertyValueFactory <>("debug1"));
          debug2.setCellValueFactory(new PropertyValueFactory <>("debug2"));
          debug3.setCellValueFactory(new PropertyValueFactory <>("debug3"));
          debug4.setCellValueFactory(new PropertyValueFactory <>("debug4"));
          ctrl1A.setCellValueFactory(new PropertyValueFactory <>("ctrl1A"));
          ctrl1E.setCellValueFactory(new PropertyValueFactory <>("ctrl1E"));
          ctrl2A.setCellValueFactory(new PropertyValueFactory <>("ctrl2A"));
          ctrl2E.setCellValueFactory(new PropertyValueFactory <>("ctrl2E"));
          ctrl3A.setCellValueFactory(new PropertyValueFactory <>("ctrl3A"));
          ctrl3E.setCellValueFactory(new PropertyValueFactory <>("ctrl3E"));
          ctrl4A.setCellValueFactory(new PropertyValueFactory <>("ctrl4A"));
          ctrl4E.setCellValueFactory(new PropertyValueFactory <>("ctrl4E"));
          ctrl5A.setCellValueFactory(new PropertyValueFactory <>("ctrl5A"));
          ctrl5E.setCellValueFactory(new PropertyValueFactory <>("ctrl5E"));

          


            
        List<String> dayLabels = Arrays.asList(
		"a","b","c","d","e","f","g");
        
        final CategoryAxis xAxis2 = new CategoryAxis();
        final NumberAxis yAxis2 = new NumberAxis();
        xAxis2.setLabel("Day");
        xAxis2.setCategories(FXCollections.<String> observableArrayList(dayLabels));
        yAxis2.setLabel("Value 2");
        XYChart.Series XYSeries2 = new XYChart.Series(myList.xyList2);
        XYSeries2.setName("XYChart.Series 2");
         
        final LineChart<String,Number> lineChart2 = 
                new LineChart<>(xAxis2,yAxis2);
        lineChart2.setTitle("Line Chart 2");
        
        lineChart2.getData().add(XYSeries2);
      
          
          XYChart.Series <Number, Number> series = new XYChart.Series<Number, Number>();

            
              final TabPane tabPane = new TabPane();  
           /*To Set Preferred Dimensions*/  
           //tabPane.setPrefSize(1366, 700);  
           tabPane.setSide(Side.TOP);  
           tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);  
 

            
            
            
            
            
           
//           int best = time.getCellData(index);
//           String a = Integer.toString(best);
            
           int best = data.size();
           size.setText(Integer.toString(best));
//           onText.setText(upSlow.getCellData(index));
           size.setEditable(false);
          // onText.setText(line);
          
            pi.setVisible(false);
}  
    
    
    
    /* Get max number of rows*/
    
    
    
    
    
    
    
    
    
        @FXML//Clear Fields 
    private void onClear(ActionEvent e) {

    table.getItems().clear();
    
    }
    
     
    
    
    @FXML//Scroll backwards 
    private void onPrevious(ActionEvent e) throws SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        
//                           for(int k = 0; k < btns.length; k++){
//                                    btns[k].setId(methodNames[k]);
//                                }   
        Method   TargetMethod = null;
            try{
               String method = dnS.getText().trim();
               method = method.replaceAll("\\s", "");
               onText.setText(method);
               for(int x = 1; x < methodNames.length; x ++){
                   if(methodNames[x].equals(method)){
                   size.setText(methodNames[x]);
                   //TargetMethod = ButtonList.get(x-1).getClass().getMethod(methodNames[x-1]);
                   // TargetMethod.invoke(ButtonList.get(x-1));
                    ButtonList.get(x-1).fire();
                     on.setText("<-");
                     onText.setText(methodNames[x-2]);
                     at.setText("->");
                   }
                   
               }
              
            } catch(Exception ex){
                ex.printStackTrace();
            }   
            
        }
            
          
    
    
    
    
    @FXML//Scroll forward through the ArrayList
    private void onNext(ActionEvent e) {

                   try{
               String method = dnS.getText().trim();
               method = method.replaceAll("\\s", "");
               onText.setText(method);
               for(int x = 1; x < methodNames.length; x ++){
                   if(methodNames[x].equalsIgnoreCase(method)){
                   size.setText(methodNames[x+2]);
                   size.setEditable(true);
                   //TargetMethod = ButtonList.get(x-1).getClass().getMethod(methodNames[x-1]);
                   // TargetMethod.invoke(ButtonList.get(x-1));
                    ButtonList.get(x+1).fire();
                     on.setText("<-");
                     onText.setText(methodNames[x]);
                     at.setText("->");
                   }
                   
               }
              
            } catch(Exception ex){
                ex.printStackTrace();
            } 
            //getlogEntry(p); 
    }
    
    
            String[] selectedCharts = new String[3];
            
    
            double minx = 0, maxx = 0, temp = 0,median,mode1=0 ;
            double avg;
            int k,z,ds;
            String xName, yName;
            int[] colvalues;
            Float[] colvalues1; 
            
            
            
            
            
            public void setBarTab(String xName, String yName, double maxx,double minx, double avg) {
            brief.getChildren().clear();
            stats.getChildren().clear();
           String barname = yName;  
           final CategoryAxis xAxis = new CategoryAxis();  
           final NumberAxis yAxis = new NumberAxis();  
           final BarChart<String,Number> bc =   
                     new BarChart<String,Number>(xAxis,yAxis);  
           bc.setTitle("Bar Chart");  
           xAxis.setLabel(xName);      
           yAxis.setLabel(yName);  
           XYChart.Series series1 = new XYChart.Series();  
           series1.setName("Minimum");      
           series1.getData().add(new XYChart.Data(barname, minx));     
           XYChart.Series series2 = new XYChart.Series();  
           series2.setName("Average");  
           series2.getData().add(new XYChart.Data(barname, avg));  
           XYChart.Series series3 = new XYChart.Series();  
           series3.setName("Maximum");  
           series3.getData().add(new XYChart.Data(barname, maxx));   
            
           bc.getData().addAll(series1,series2,series3);  
           
           

           //scrollpane2.setContent(maintabpane);
           
             
             
           ObservableList<PieChart.Data> pieChartData =  
                     FXCollections.observableArrayList(  
                               new PieChart.Data("Parameter 1", 10),  
                               new PieChart.Data("Parameter 2", 15),  
                               new PieChart.Data("Parameter 3", 25),  
                               new PieChart.Data("Parameter 4", 35),  
                               new PieChart.Data("Parameter 5", 50));  
           final PieChart chart = new PieChart(pieChartData);  
           chart.setTitle("Parameter Statistics");  
            changePieColor(pieChartData, "#cccccc","#cccccc","#cccccc","#cccccc","#cccccc");
           
           
           stats.getChildren().addAll(chart);
           
           
           brief.getChildren().addAll(bc);
           
    }
       
    @FXML//Load upSlowChart
    private void upSlowChart() {
        
            pi.setVisible(true);
            pi.toFront();
            
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();
        xAxiss.setLabel("time");       
        yAxiss.setLabel("UpSlow");
        
                
        lineChart.setTitle("upslow/time");
                                
        
        series.setName("Portfolio 1");
        
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
             
    int ds = data.size();
    
    int[] colvalues  = new int[ds];
        
         
        
                       for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(upSlow.getCellData(k))));
                            colvalues[k] = Integer.parseInt(upSlow.getCellData(k));
        
                        }
                       
                       
         median = colvalues[ds/2];
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;


        
        lineChart.getData().add(series);
        
        dnS.setText("upSlow chart");
        dnS.setContent(lineChart);
        
        setBarTab( xName,  yName,  maxx, minx,  avg);
            try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
        
            pi.setVisible(false);
          
            }     
    
    
    @FXML//Load UpFast Chart
    private void UpFastChart() {

                  
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();  
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("upfast");
                
        lineChart.setTitle("upfast/time");
                                
        series.setName("Portfolio 2");
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
        
    int ds = data.size();
   
    int[] colvalues  = new int[ds];    
         
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(upFast.getCellData(k))));
                            colvalues[k] = Integer.parseInt(upFast.getCellData(k));
        
                        }
                      
                      
          median = colvalues[ds/2];         
        for(int k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for (int z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                   
                  dnS.setText("UpFast chart");
                  dnS.setContent(lineChart);
                   
                   
                   setBarTab( xName,  yName,  maxx, minx,  avg);
                   
                               try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load rtFast  Chart
    private void rtFastChart() {

                 
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();   
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("rtfast");
        
                
        lineChart.setTitle("rtfast/time");
                                
        series.setName("Portfolio 6");
        
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
        
    int ds = data.size();
   
    int[] colvalues  = new int[ds];
    
         
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(rtFast.getCellData(k))));
                            colvalues[k] = Integer.parseInt(rtFast.getCellData(k));
        
                        }
                       
                      
           median = colvalues[ds/2];        
        for(int k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for (int z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
        
        
        
                       lineChart.getData().add(series);
                   
                  dnS.setText("Rtfast chart");
                  dnS.setContent(lineChart);
                   
                   setBarTab( xName,  yName,  maxx, minx,  avg);
                   
                                     try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load dnSlow  Chart
    private void dnSlowChart() {

                  
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();  
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("dnSlow");
                
        lineChart.setTitle("dnSlow/time");
                                
        series.setName("Portfolio 3");
        
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
        
    int ds = data.size();
    
    int[] colvalues  = new int[ds];    
         
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(dnSlow.getCellData(k))));
                            colvalues[k] = Integer.parseInt(dnSlow.getCellData(k));
        
                        }
                      
              median = colvalues[ds/2];     
        for(int k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for (int z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                 
                  dnS.setText("DnSlow chart");
                  dnS.setContent(lineChart);
                   
                   
                   setBarTab( xName,  yName,  maxx, minx,  avg);
                   
                                     try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load dnFast Chart  
    private void dnFastChart() {
        
             
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();       
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("dnfast");
        
                
        lineChart.setTitle("dnfast/time");
                                
        series.setName("Portfolio 4");
        
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
        
        
    int ds = data.size();
    
    int[] colvalues  = new int[ds];
    
         
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(dnFast.getCellData(k))));
                            colvalues[k] = Integer.parseInt(dnFast.getCellData(k));
        
                        }
                       
             median = colvalues[ds/2];         
        for(int k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for (int z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                      
                       lineChart.getData().add(series);
                   
                  dnS.setText("Dnfast chart");
                  dnS.setContent(lineChart);
                   
          setBarTab( xName,  yName,  maxx, minx,  avg);         
                 
                            try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
                   
            }
    
    
    
    @FXML//Load rtSlow Chart  
    private void rtSlowChart() {

                  
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();  
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("rtSlow");
                
        lineChart.setTitle("rtSlow/time");
                                
        series.setName("Portfolio 5");
        
        
    int ds = data.size();
    
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();

    int[] colvalues  = new int[ds];  
         
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(rtSlow.getCellData(k))));
                            colvalues[k] = Integer.parseInt(rtSlow.getCellData(k));
        
                        }
                       
               median = colvalues[ds/2];    
        for(int k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for (int z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                      
                       lineChart.getData().add(series);
                   
                  dnS.setText("rtSlow chart");
                  dnS.setContent(lineChart);
                  
                setBarTab( xName,  yName,  maxx, minx,  avg);   
                
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
         

    @FXML//Load ltSlow Chart  
    private void ltSlowChart() {

                
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();    
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("ltSlow");
                
        lineChart.setTitle("ltSlow/time");
                                
        series.setName("Portfolio 7");
        
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
        
    int ds = data.size();
    int[] colvalues  = new int[ds];
        
         
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(ltSlow.getCellData(k))));
                            colvalues[k] = Integer.parseInt(ltSlow.getCellData(k));
        
                        }
                       
                      
              median = colvalues[ds/2];     
        for(int k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for (int z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
        
                       lineChart.getData().add(series);
                  
                  dnS.setText("ltSlowChart");
                  dnS.setContent(lineChart);
                   
              setBarTab( xName,  yName,  maxx, minx,  avg);     
                 
                                try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load ltFast Chart  
    private void ltFastchart() {

              
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();      
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("ltFast");
                
        lineChart.setTitle("ltFast/time");
                                
        series.setName("Portfolio 8");
        
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
        
    int ds = data.size();
    int[] colvalues  = new int[ds];
    
    
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(ltFast.getCellData(k))));
                            colvalues[k] = Integer.parseInt(ltFast.getCellData(k)); 
        
                        }
                      
                median = colvalues[ds/2];   
        for(int k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for (int z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                 
                  dnS.setText("ltFastchart");
                  dnS.setContent(lineChart);
                   
             setBarTab( xName,  yName,  maxx, minx,  avg);      
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }   
            }
    
    @FXML//Load feedAcc Chart  
    private void feedAccchart() {

                
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();    
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("feedAcc");
                
        lineChart.setTitle("feedAcc/time");
                                
        series.setName("Portfolio 9");
        
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
        
    int ds = data.size();
    int[] colvalues  = new int[ds];
    
    
    
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(feedAcc.getCellData(k))));
                            colvalues[k] = Integer.parseInt(feedAcc.getCellData(k));
        
                        }
                       
                 median = colvalues[ds/2];  
        for(int k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for (int z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                      
                       lineChart.getData().add(series);
                   
                  dnS.setText("feedAcc chart");
                  dnS.setContent(lineChart);
                   
              setBarTab( xName,  yName,  maxx, minx,  avg);      
                                 try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }    
            }
    
    
    @FXML//Load stowchart Chart  
    private void stowchart() {

                 
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();   
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("stow");
                
        lineChart.setTitle("stow/time");
                                
        series.setName("Portfolio 10");
        
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
        
    int ds = data.size();
    int[] colvalues  = new int[ds];
    
    
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(stow.getCellData(k))));
                            colvalues[k] = Integer.parseInt(stow.getCellData(k));
        
                        }
                       
                  median = colvalues[ds/2]; 
        for(int k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for (int z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                      
                       lineChart.getData().add(series);
                  
                  dnS.setText("stow chart");
                  dnS.setContent(lineChart);
                   
           setBarTab( xName,  yName,  maxx, minx,  avg);        
                               try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }      
            }
    
    
    @FXML//Load remotechart Chart  
    private void remotechart() {

                 
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();   
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("remote");
                
        lineChart.setTitle("remote/time");
                                
        series.setName("Portfolio 11");
        
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
        
    int ds = data.size();
     colvalues  = new int[ds];

                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(remote.getCellData(k))));
                            colvalues[k] = Integer.parseInt(remote.getCellData(k));
        
                        }
                      
            median = colvalues[ds/2];       
        for(int k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for (int z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                   
                  dnS.setText("remote chart");
                  dnS.setContent(lineChart);
                  
                  
             setBarTab( xName,  yName,  maxx, minx,  avg);      
                                try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }     
                   
            }
    
    
    
    @FXML//Load remotechart Chart  
    private void localchart() {
        dnS.setContent(null);
                
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();    
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("local");
                
        lineChart.setTitle("local/time");
                                
        series.setName("Portfolio 12");
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
        
    int ds = data.size();
     colvalues  = new int[ds];
    
    
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(local.getCellData(k))));
                            colvalues[k] = Integer.parseInt(local.getCellData(k));
        
                        }
                      
               median = colvalues[ds/2];       
        for(int k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for (int z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                   
                  dnS.setText("local chart");
                  dnS.setContent(lineChart);
                   
         setBarTab( xName,  yName,  maxx, minx,  avg);          
                                try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }     
            }
    
    
    @FXML//Load VtripE380chart Chart  
    private void VtripE380chart() {

              
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();      
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("VtripE380");
        
        
                
        lineChart.setTitle("VtripE380/time");
                                
        series.setName("Portfolio 13");
        
        xName = xAxiss.getLabel();
        yName = yAxiss.getLabel();
        
    ds = data.size();
    colvalues  = new int[ds];
    
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(VtripE380.getCellData(k))));
                            colvalues[k] = Integer.parseInt(VtripE380.getCellData(k));
        
                        }
                      
                median = colvalues[ds/2];      
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                 
                  dnS.setText("VtripE380 chart");
                  dnS.setContent(lineChart);
                   
           setBarTab( xName,  yName,  maxx, minx,  avg);        
                               try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }      
            }
    
    
    
    
    @FXML//Load VtripE380chart Chart  
    private void brkRoffEchart() {

                  
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();  
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("brkRoffE");
                
        lineChart.setTitle("brkRoffE/time");
                                
        series.setName("Portfolio 14");
        
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
        
     ds = data.size();
     colvalues  = new int[ds];
     
     
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(brkRoffE.getCellData(k))));
                            colvalues[k] = Integer.parseInt(brkRoffE.getCellData(k));
        
                        }
                       
                      
                      median = colvalues[ds/2];
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                      
                       lineChart.getData().add(series);
                  
                  dnS.setText("brkRoffE chart");
                  dnS.setContent(lineChart);
                   
            setBarTab( xName,  yName,  maxx, minx,  avg);       
                               try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }      
            }
    
    
    
    @FXML//Load VonE24chart Chart  
    private void VonE24chart() {

                 
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();   
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("VonE24");
                
        lineChart.setTitle("VonE24/time");
                                
        series.setName("Portfolio 15");
        
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
        
     ds = data.size();
     colvalues  = new int[ds];
     
     
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(VonE24.getCellData(k))));
                            colvalues[k] = Integer.parseInt(VonE24.getCellData(k));
        
                        }
                      
                  median = colvalues[ds/2];    
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                   
                  dnS.setText("VonE24 chart");
                  dnS.setContent(lineChart);
                   
           setBarTab( xName,  yName,  maxx, minx,  avg);         
                                 try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }    
            }
    
    
    
    @FXML//Load Voff380chart Chart  
    private void Voff380chart() {

          
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();          
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("Voff380");

                
        lineChart.setTitle("Voff380/time");
                                
        series.setName("Portfolio 16");
        
        
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();
        
     ds = data.size();
     colvalues  = new int[ds];
     
     
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(Voff380.getCellData(k))));
                            colvalues[k] = Integer.parseInt(Voff380.getCellData(k));
        
                        }
                      
                      median = colvalues[ds/2];
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                   
                  dnS.setText("Voff380 chart");
                  dnS.setContent(lineChart);
                   
          setBarTab( xName,  yName,  maxx, minx,  avg);         
                               try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }      
            }
    
    
    @FXML//Load Voff380chart Chart  
    private void VtripA380chart() {
        
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();
                    
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("VtripA380");
                
        lineChart.setTitle("VtripA380/time");
                                
        series.setName("Portfolio 17");
        
        xName = xAxiss.getLabel();
        yName = yAxiss.getLabel();
        
    ds = data.size();
    colvalues  = new int[ds];
    
    
                      for ( k = 0; k < ds ; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(VtripA380.getCellData(k))));
                            colvalues[k] = Integer.parseInt(VtripA380.getCellData(k));
        
                        }
                      
                   median = colvalues[ds/2];   
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                  
                  dnS.setText("VtripA380 chart");
                  dnS.setContent(lineChart);
                   
              setBarTab( xName,  yName,  maxx, minx,  avg);     
                   
                                try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }     
                   
            }
    
    
    
    @FXML//Load brkRoffAchart Chart  
    private void brkRoffAchart() {
        
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();
                    
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("brkRoffA");
                
        lineChart.setTitle("brkRoffA/time");
                                
        series.setName("Portfolio 18");
        
        xName = xAxiss.getLabel();
        yName = yAxiss.getLabel();

        
    ds = data.size();
    colvalues  = new int[ds];
    
    
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(brkRoffA.getCellData(k))));
                            colvalues[k] = Integer.parseInt(brkRoffA.getCellData(k));

        
                        }
                      
                   median = colvalues[ds/2];   
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                   
                  dnS.setText("brkRoffA chart");
                  dnS.setContent(lineChart);
                   
          setBarTab( xName,  yName,  maxx, minx,  avg);         
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }   
                   
                   
            }
    
    
    @FXML//Load VonA24chart Chart  
    private void VonA24chart() {
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


     
        
        XYChart.Series series = new XYChart.Series();
            
        xAxis.setLabel("Time");       
        yAxis.setLabel("VonA24");

                
        lineChart.setTitle("VonA24/time");
                                
        series.setName("Portfolio 19");
        
        xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
    ds = data.size();
    colvalues  = new int[ds];

                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(VonA24.getCellData(k))));
                            colvalues[k] = Integer.parseInt(VonA24.getCellData(k));

        
                        }
                      
                      
                   median = colvalues[ds/2];   
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                  
                  dnS.setText("VonA24 chart");
                  dnS.setContent(lineChart);
            setBarTab( xName,  yName,  maxx, minx,  avg);
                              try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load Von24chart Chart  
    private void Von24chart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            
        xAxis.setLabel("Time");       
        yAxis.setLabel("Von24");
                
        lineChart.setTitle("Von24/time");
                                
        series.setName("Portfolio 20");
        
        xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
     colvalues  = new int[ds];
     
     
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(Von24.getCellData(k))));
                            colvalues[k] = Integer.parseInt(Von24.getCellData(k));
                        }
                      
                   median = colvalues[ds/2];   
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       
                       lineChart.getData().add(series);
                   
                  dnS.setText("Von24 chart");
                  dnS.setContent(lineChart);
                  
              setBarTab( xName,  yName,  maxx, minx,  avg);
                               try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            } 
            }
    
    
    @FXML//Load overHlimchart Chart  
    private void overHlimchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("overHlim");
                
        lineChart.setTitle("overHlim/time");
                                
        series.setName("Portfolio 21");
        
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
     colvalues  = new int[ds];
     
     
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(overHlim.getCellData(k))));
                            colvalues[k] = Integer.parseInt(overHlim.getCellData(k));
                        }
                       median = colvalues[ds/2];
                      for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                      
                      
                       lineChart.getData().add(series);
                   
                  dnS.setText("overHlim chart");
                  dnS.setContent(lineChart);
                  
               setBarTab( xName,  yName,  maxx, minx,  avg);    
                                 try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load tBoxOverchart Chart  
    private void tBoxOverchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("tBoxOver");
                
        lineChart.setTitle("tBoxOver/time");
                                
        series.setName("Portfolio 22");
        
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
     ds = data.size();
     colvalues  = new int[ds];
     
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(tBoxOver.getCellData(k))));
                            colvalues[k] = Integer.parseInt(tBoxOver.getCellData(k));
                        }
                       
                    median = colvalues[ds/2];  
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                      
                       lineChart.getData().add(series);
                  
                  dnS.setText("tBoxOver chart");
                  dnS.setContent(lineChart);
              
                  setBarTab( xName,  yName,  maxx, minx,  avg);
                                 try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }   
            }
    
    
    @FXML//Load notEstopchart Chart  
    private void notEstopchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("notEstop");
                
        lineChart.setTitle("notEstop/time");
                                
        series.setName("Portfolio 23");
        
        xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
     ds = data.size();
     colvalues  = new int[ds];
     
     
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(notEstop.getCellData(k))));
                            colvalues[k] = Integer.parseInt(notEstop.getCellData(k));
                        }
                      median = colvalues[ds/2];
                       for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                   
                  dnS.setText("notEstop chart");
                  dnS.setContent(lineChart);
                  
                   setBarTab( xName,  yName,  maxx, minx,  avg);
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }       
            }
    
    
    @FXML//Load overlap1chart Chart  
    private void overlap1chart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("overlap1");
                
        lineChart.setTitle("overlap1/time");
                                
        series.setName("Portfolio 24");
        
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
    ds = data.size();
    colvalues  = new int[ds];
    
    
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(overlap1.getCellData(k))));
                            colvalues[k] = Integer.parseInt(overlap1.getCellData(k));
                        }
                      median = colvalues[ds/2];
                       for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                   
                  dnS.setText("overlap1 chart");
                  dnS.setContent(lineChart);
                  
                  setBarTab( xName,  yName,  maxx, minx,  avg);
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }       
            }
    
    
    
    @FXML//Load enReqEchart Chart  
    private void enReqEchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("enReqE");
                
        lineChart.setTitle("enReqE/time");
                                
        series.setName("Portfolio 25");
        
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
    ds = data.size();
    colvalues  = new int[ds];

                      for ( k = 0; k < ds ; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(enReqE.getCellData(k))));
                            colvalues[k] = Integer.parseInt(enReqE.getCellData(k));
                        }
                      
                   median = colvalues[ds/2];   
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                  
                  dnS.setText("enReqE chart");
                  dnS.setContent(lineChart);
                  
                  setBarTab( xName,  yName,  maxx, minx,  avg);
                                try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }         
            }
    
    
    @FXML//Load enEchart Chart  
    private void enEchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("enE");
                
        lineChart.setTitle("enE/time");
                                
        series.setName("Portfolio 26");
        
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
     colvalues  = new int[ds];
     
     
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(enE.getCellData(k))));
                            colvalues[k] = Integer.parseInt(enE.getCellData(k));

                        }
                       median = colvalues[ds/2];
                      for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;


                      
                       lineChart.getData().add(series);
                   
                  dnS.setText("enE chart");
                  dnS.setContent(lineChart);
                  
                   setBarTab( xName,  yName,  maxx, minx,  avg);
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
                                    
            }
    
    
    
    @FXML//Load topHlimchart Chart  
    private void topHlimchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
         dnS.setContent(null);   
        xAxis.setLabel("Time");       
        yAxis.setLabel("topHlim");
                
        lineChart.setTitle("topHlim/time");
                                
        series.setName("Portfolio 27");
       
        xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
    ds = data.size();
     colvalues  = new int[ds];
     
     
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(topHlim.getCellData(k))));
                            colvalues[k] = Integer.parseInt(topHlim.getCellData(k));

                        }
                       median = colvalues[ds/2];
                       for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                      
                       lineChart.getData().add(series);
               
                  dnS.setText("topHlim chart");
                  dnS.setContent(lineChart);
                  
                  setBarTab( xName,  yName,  maxx, minx,  avg);
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }       
            }
    
    
    @FXML//Load botHlimchart Chart  
    private void botHlimchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
          dnS.setContent(null);  
        xAxis.setLabel("Time");       
        yAxis.setLabel("botHlim");
                
        lineChart.setTitle("botHlim/time");
                                
        series.setName("Portfolio 28");
       
        xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
    colvalues  = new int[ds];
    
    
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(botHlim.getCellData(k))));
                            colvalues[k] = Integer.parseInt(botHlim.getCellData(k));
                        }
                      median = colvalues[ds/2];
                      for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                  
                  dnS.setText("botHlim chart");
                  dnS.setContent(lineChart);
                  
                  setBarTab( xName,  yName,  maxx, minx,  avg);
                                 try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }         
            }
    
    
    
    @FXML//Load notTopFlimchart Chart  
    private void notTopFlimchart() {
           dnS.setContent(null); 
           
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            
        xAxis.setLabel("Time");       
        yAxis.setLabel("notTopFlim");
                
        lineChart.setTitle("notTopFlim/time");
                                
        series.setName("Portfolio 29");
        
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
     colvalues  = new int[ds];
     
     
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(notTopFlim.getCellData(k))));
                            colvalues[k] = Integer.parseInt(notTopFlim.getCellData(k));
                        }
                       median = colvalues[ds/2];
                       for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                      
                       lineChart.getData().add(series);
                   
                  dnS.setText("notTopFlim chart");
                  dnS.setContent(lineChart);
                  
                   setBarTab( xName,  yName,  maxx, minx,  avg);
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }       
            }
    
    
    @FXML//Load notBotFlimchart Chart  
    private void notBotFlimchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("notBotFlim");

                
        lineChart.setTitle("notBotFlim/time");
                                
        series.setName("Portfolio 30");
        
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
     colvalues  = new int[ds];
     
     
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(notBotFlim.getCellData(k))));
                            colvalues[k] = Integer.parseInt(notBotFlim.getCellData(k));


                        }
                      median = colvalues[ds/2];
                        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                   
                  dnS.setText("notBotFlim chart");
                  dnS.setContent(lineChart);
                      
                  setBarTab( xName,  yName,  maxx, minx,  avg);
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load bkStowchart Chart  
    private void bkStowchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("bkStow");
                
        lineChart.setTitle("bkStow/time");
                                
        series.setName("Portfolio 31");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
      colvalues  = new int[ds];
      
      
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(bkStow.getCellData(k))));
                            colvalues[k] = Integer.parseInt(bkStow.getCellData(k));
                        }
                       
                      median = colvalues[ds/2];
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                      
                       lineChart.getData().add(series);
                   
                  dnS.setText("bkStow chart");
                  dnS.setContent(lineChart);
                 setBarTab( xName,  yName,  maxx, minx,  avg);  
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load brakeEchart Chart  
    private void brakeEchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
         dnS.setContent(null);   
        xAxis.setLabel("Time");       
        yAxis.setLabel("brakeE");
                
        lineChart.setTitle("brakeE/time");
                                
        series.setName("Portfolio 32");
        
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
    ds = data.size();
     colvalues  = new int[ds];
     
     
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(brakeE.getCellData(k))));
                            colvalues[k] = Integer.parseInt(brakeE.getCellData(k));

                        }
                       median = colvalues[ds/2];
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
        
                       lineChart.getData().add(series);
                 
                  dnS.setText("brakeE chart");
                  dnS.setContent(lineChart);
                setBarTab( xName,  yName,  maxx, minx,  avg);    
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load enReqAchart Chart  
    private void enReqAchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
           dnS.setContent(null); 
        xAxis.setLabel("Time");       
        yAxis.setLabel("enReqA");

                
        lineChart.setTitle("enReqA/time");
                                
        series.setName("Portfolio 33");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
    ds = data.size();
     colvalues  = new int[ds];
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(enReqA.getCellData(k))));
                            colvalues[k] = Integer.parseInt(enReqA.getCellData(k));

                        }
                      median = colvalues[ds/2];
                       for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       
                       lineChart.getData().add(series);
                  
                  dnS.setText("enReqA chart");
                  dnS.setContent(lineChart);
               setBarTab( xName,  yName,  maxx, minx,  avg);   
                                 try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load enAchart Chart  
    private void enAchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("enA");
                
        lineChart.setTitle("enA/time");
                                
        series.setName("Portfolio 34");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
     colvalues  = new int[ds];

                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(enA.getCellData(k))));
                            colvalues[k] = Integer.parseInt(enA.getCellData(k));

                        }
                      median = colvalues[ds/2];
                      for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
 
                      
                       lineChart.getData().add(series);
                       
                  
                  dnS.setText("enA chart");
                  dnS.setContent(lineChart);
                 setBarTab( xName,  yName,  maxx, minx,  avg); 
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load rtHlimchart Chart  
    private void rtHlimchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("rtHlim");
                
        lineChart.setTitle("rtHlim/time");
                                
        series.setName("Portfolio 35");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
    colvalues  = new int[ds];
    
    
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(rtHlim.getCellData(k))));
                            colvalues[k] = Integer.parseInt(rtHlim.getCellData(k));

                        }
                      
                     median = colvalues[ds/2]; 
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       
                       lineChart.getData().add(series);
                  
                  dnS.setText("rtHlim chart");
                  dnS.setContent(lineChart);
                setBarTab( xName,  yName,  maxx, minx,  avg);     
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load ltHlim Chart  
    private void ltHlimchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("ltHlim");
                
        lineChart.setTitle("ltHlim/time");
                                
        series.setName("Portfolio 36");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
    colvalues  = new int[ds];
    
    
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(ltHlim.getCellData(k))));
                          colvalues[k] = Integer.parseInt(ltHlim.getCellData(k));  
                        }
                       
                    median = colvalues[ds/2];  
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                
                  dnS.setText("ltHlim chart");
                  dnS.setContent(lineChart);
                   setBarTab( xName,  yName,  maxx, minx,  avg);  
                                     try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load notRtFlimchart Chart  
    private void notRtFlimchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("notRtFlim");
                
        lineChart.setTitle("notRtFlim/time");
                                
        series.setName("Portfolio 37");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
     ds = data.size();
    colvalues  = new int[ds];


                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(notRtFlim.getCellData(k))));
                            colvalues[k] = Integer.parseInt(notRtFlim.getCellData(k));

                        }
                      median = colvalues[ds/2];
                       for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                  
                  dnS.setText("notRtFlim chart");
                  dnS.setContent(lineChart);
                 setBarTab( xName,  yName,  maxx, minx,  avg);      
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load notLtFlimchart Chart  
    private void notLtFlimchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("notLtFlim");
                
        lineChart.setTitle("notLtFlim/time");
                                
        series.setName("Portfolio 38");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
    colvalues  = new int[ds];

                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(notLtFlim.getCellData(k))));
                            colvalues[k] = Integer.parseInt(notLtFlim.getCellData(k));

                        }
                      median = colvalues[ds/2];
                        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                
                  dnS.setText("notLtFlim chart");
                  dnS.setContent(lineChart);
                  setBarTab( xName,  yName,  maxx, minx,  avg);    
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load overlap2chart Chart  
    private void overlap2chart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("overlap2");

                
        lineChart.setTitle("overlap2/time");
                                
        series.setName("Portfolio 39");
          xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
     ds = data.size();
     colvalues  = new int[ds];
     
     
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(overlap2.getCellData(k))));
                            colvalues[k] = Integer.parseInt(overlap2.getCellData(k));

                        }
                      median = colvalues[ds/2];
                       for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                 
                  dnS.setText("overlap2 chart");
                  dnS.setContent(lineChart);
                setBarTab( xName,  yName,  maxx, minx,  avg);   
                
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load brakeAchart Chart  
    private void brakeAchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("brakeA");

                
        lineChart.setTitle("brakeA/time");
                                
        series.setName("Portfolio 40");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
    colvalues  = new int[ds];
    
    
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(brakeA.getCellData(k))));
                            colvalues[k] = Integer.parseInt(brakeA.getCellData(k));


                        }
                      median = colvalues[ds/2];
                        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                   
                  dnS.setText("brakeA chart");
                  dnS.setContent(lineChart);
                 setBarTab( xName,  yName,  maxx, minx,  avg);  
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load drStateAchart Chart  
    private void drStateAchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
        // maintabpane.getTabs().remove(dnS);
        xAxis.setLabel("Time");       
        yAxis.setLabel("drStateA");

                
        lineChart.setTitle("drStateA/time");
                                
        series.setName("Portfolio 41");
        
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
     colvalues  = new int[ds];

                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(drStateA.getCellData(k))));
                            colvalues[k] = Integer.parseInt(drStateA.getCellData(k));


                        }
                      median = colvalues[ds/2]; 
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
               //maintabpane.getTabs().add(dnS);
                //  dnS.setContent(null);
                  dnS.setText("drStateA chart");
                  dnS.setContent(lineChart);
                    setBarTab( xName,  yName,  maxx, minx,  avg);  
                                      try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load drStateEchart Chart  
    private void drStateEchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("drStateE");
                
        lineChart.setTitle("drStateE/time");
                                
        series.setName("Portfolio 42");
          xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
   ds = data.size();
     colvalues  = new int[ds];

                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(drStateE.getCellData(k))));
                            colvalues[k] = Integer.parseInt(drStateE.getCellData(k));



                        }
                      median = colvalues[ds/2];
                         for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                 
                  dnS.setText("drStateE chart");
                  dnS.setContent(lineChart);
                   setBarTab( xName,  yName,  maxx, minx,  avg);    
                                     try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load modeReqchart Chart  
    private void modeReqchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("modeReq");
                
        lineChart.setTitle("modeReq/time");
                                
        series.setName("Portfolio 43");
        
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
    ds = data.size();
     colvalues  = new int[ds];
     
                      for (k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(modeReq.getCellData(k))));
                            colvalues[k] = Integer.parseInt(modeReq.getCellData(k));



                        }
                      
                      median = colvalues[ds/2];
                      
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       
                       lineChart.getData().add(series);
                   
                  dnS.setText("modeReq chart");
                  dnS.setContent(lineChart);
                    setBarTab( xName,  yName,  maxx, minx,  avg);  
                                      try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load modechart Chart  
    private void modechart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
            dnS.setContent(null);
        xAxis.setLabel("Time");       
        yAxis.setLabel("mode");

                
        lineChart.setTitle("mode/time");
                                
        series.setName("Portfolio 44");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
     colvalues  = new int[ds];
     
     
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(mode.getCellData(k))));
                            colvalues[k] = Integer.parseInt(mode.getCellData(k));

                        }
                       median = colvalues[ds/2];
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                   
                  dnS.setText("mode chart");
                  dnS.setContent(lineChart);
                   setBarTab( xName,  yName,  maxx, minx,  avg);    
                   
                                     try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load selStatechart Chart  
    private void selStatechart() {
        
        
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxiss,yAxiss);


        XYChart.Series series = new XYChart.Series();
           dnS.setContent(null); 
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("selState");
                
        lineChart.setTitle("selState/time");
                                
        series.setName("Portfolio 45");
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();

        
     ds = data.size();
    colvalues  = new int[ds];
    
    
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(selState.getCellData(k))));
                            colvalues[k] = Integer.parseInt(selState.getCellData(k));


                        }
                       median = colvalues[ds/2];
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                 
                  dnS.setText("selState chart");
                  dnS.setContent(lineChart);
                 setBarTab( xName,  yName,  maxx, minx,  avg);    
                 
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load funcStatechart Chart  
    private void funcStatechart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
           dnS.setContent(null); 
           ac.getChildren().clear();
        xAxis.setLabel("Time");       
        yAxis.setLabel("funcState");
                
        lineChart.setTitle("funcState/time");
                                
        series.setName("Portfolio 46");
          xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
     ds = data.size();
     colvalues  = new int[ds];

                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(funcState.getCellData(k))));
                            colvalues[k] = Integer.parseInt(funcState.getCellData(k));
                        }
                      
                      median = colvalues[ds/2];
                        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                   
                  dnS.setText("funcState chart");
                  dnS.setContent(lineChart);
                  setBarTab( xName,  yName,  maxx, minx,  avg);    
                  
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load ntpchart Chart  
    private void ntpchart() {
        
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
        
           dnS.setContent(null);
           ac.getChildren().clear();
        xAxis.setLabel("Time");       
        yAxis.setLabel("ntpchart");
                
        lineChart.setTitle("ntpchart/time");
                                
        series.setName("Portfolio 47");
          xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
    colvalues  = new int[ds];
    
    
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(ntp.getCellData(k))));
                            colvalues[k] = Integer.parseInt(ntp.getCellData(k));


                        }
                      median = colvalues[ds/2]; 
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                 
                  dnS.setText("ntp chart");
                  dnS.setContent(lineChart);
                 
                setBarTab( xName,  yName,  maxx, minx,  avg);    
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load posReqAchart Chart  
    private void posReqAchart() {
        
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
        
          dnS.setContent(null);
          ac.getChildren().clear();
        xAxis.setLabel("Time");       
        yAxis.setLabel("posReqA");

                
        lineChart.setTitle("posReqA/time");
                                
        series.setName("Portfolio 49");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
    ds = data.size();
    Float[] colvalues  = new Float[ds];

                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Float.parseFloat(posReqA.getCellData(k))));
                            colvalues[k] = Float.parseFloat(posReqA.getCellData(k));

                        }
                      median = colvalues[ds/2];
                        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                   
                  dnS.setText("posReqA chart");
                  dnS.setContent(lineChart);
                  setBarTab( xName,  yName,  maxx, minx,  avg);     
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load timeReqchart Chart  
    private void timeReqchart() {
         ac.getChildren().clear();
         
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();


        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);


        XYChart.Series series = new XYChart.Series();
        xAxis.setLabel("Time");       
        yAxis.setLabel("timeReq");

                
        lineChart.setTitle("timeReq/time");
                                
        series.setName("Portfolio 48");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
     ds = data.size();
    float[] colvalues  = new float[ds];

                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(timeReq.getCellData(k))/(10^11))));
                            colvalues[k] = Float.parseFloat(timeReq.getCellData(k)) /(10^11);


                        }
                       median = colvalues[ds/2];
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;


                       lineChart.getData().add(series);
                 
                  dnS.setText("timeReq chart");
                  dnS.setContent(lineChart);
                   setBarTab( xName,  yName,  maxx, minx,  avg);
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }      
            }
    
    
    @FXML//Load posDesAchart Chart  
    private void posDesAchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("posDesA");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("posDesA/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 50");
          xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
     ds = data.size();
     colvalues1  = new Float[ds];
     
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(posDesA.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(posDesA.getCellData(k));


                        }
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                  
                  dnS.setText("posDesA chart");
                  dnS.setContent(lineChart);
                setBarTab( xName,  yName,  maxx, minx,  avg);    
                
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load posActAchart Chart  
    private void posActAchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("posActA");
        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);
                
        lineChart.setTitle("posActA/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 51");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
         ds = data.size();
         colvalues1  = new Float[ds];
         
         
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(posActA.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(posActA.getCellData(k));
                        }
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                   
                  dnS.setText("posActA chart");
                  dnS.setContent(lineChart);
                setBarTab( xName,  yName,  maxx, minx,  avg);  
                
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load posReqEchart Chart  
    private void posReqEchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("posReqE");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("posReqE/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 52");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
    ds = data.size();
     colvalues1  = new Float[ds];

                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(posReqE.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(posReqE.getCellData(k));

                        }
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                 
                  dnS.setText("posReqE chart");
                  dnS.setContent(lineChart);
                setBarTab( xName,  yName,  maxx, minx,  avg); 
                
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load posDesEchart Chart  
    private void posDesEchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("posDesE");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("posDesE/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 53");
          xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
    ds = data.size();
    colvalues1  = new Float[ds];

                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(posDesE.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(posDesE.getCellData(k));

                        }
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                  
                  dnS.setText("posDesE chart");
                  dnS.setContent(lineChart);
                 setBarTab( xName,  yName,  maxx, minx,  avg);  
                 
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load posActEchart Chart  
    private void posActEchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("posActE");

        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("posActE/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 54");
        xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
         ds = data.size();
        colvalues1  = new Float[ds];

                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(posActE.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(posActE.getCellData(k));

                        }
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                 
                  dnS.setText("posActE chart");
                  dnS.setContent(lineChart);
               setBarTab( xName,  yName,  maxx, minx,  avg);  
                                 try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load mVelAchart Chart  
    private void mVelAchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("mVelA");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("mVelA/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 55");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
         ds = data.size();
         colvalues1  = new Float[ds];
         
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(mVelA.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(mVelA.getCellData(k));

                        }
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                  
                  dnS.setText("mVelA chart");
                  dnS.setContent(lineChart);
               setBarTab( xName,  yName,  maxx, minx,  avg);   
                                 try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load mReqAchart Chart  
    private void mReqAchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("mReqA");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("mReqA/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 56");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
    ds = data.size();
    colvalues1  = new Float[ds];
    
    
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(mReqA.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(mReqA.getCellData(k));

                        }
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                   
                  dnS.setText("mReqA chart");
                  dnS.setContent(lineChart);
                 setBarTab( xName,  yName,  maxx, minx,  avg);     
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load mVelEchart Chart  
    private void mVelEchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("mVelE");

        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);
                
        lineChart.setTitle("mVelE/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 57");
          xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
    ds = data.size();
    colvalues1  = new Float[ds];
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(mVelE.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(mVelE.getCellData(k));

                        }
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                 
                  dnS.setText("mVelE chart");
                  dnS.setContent(lineChart);
                  setBarTab( xName,  yName,  maxx, minx,  avg);    
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load mReqEchart Chart  
    private void mReqEchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("mReqE");
        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);
                
        lineChart.setTitle("mReqE/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 58");
        xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
    colvalues1  = new Float[ds];
    
    
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(mReqE.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(mReqE.getCellData(k));
                        }
                      median = colvalues1[ds/2];
                       for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                
                  dnS.setText("mReqE chart");
                  dnS.setContent(lineChart);
                 setBarTab( xName,  yName,  maxx, minx,  avg);     
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load mTorqAchart Chart  
    private void mTorqAchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("mTorqA");

        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);
                
        lineChart.setTitle("mTorqA/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 59");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
  colvalues1  = new Float[ds];
  
  
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(mTorqA.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(mTorqA.getCellData(k));
                        }
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                  
                  dnS.setText("mTorqA chart");
                  dnS.setContent(lineChart);
                 setBarTab( xName,  yName,  maxx, minx,  avg);   
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load mTorqEchart Chart  
    private void mTorqEchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("mTorqE");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("mTorqE/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 60");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
         ds = data.size();
        colvalues1  = new Float[ds];

                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(mTorqE.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(mTorqE.getCellData(k));

                        }
                      
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                 
                  dnS.setText("mTorqE chart");
                  dnS.setContent(lineChart);
                 setBarTab( xName,  yName,  maxx, minx,  avg);  
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load mPosAchart Chart  
    private void mPosAchart() {
            
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("mPosA");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxiss,yAxiss);
                
        lineChart.setTitle("mPosA/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 61");
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();

        
    ds = data.size();
   colvalues  = new int[ds];

                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(mPosA.getCellData(k))));
                            colvalues[k] = Integer.parseInt(mPosA.getCellData(k));

                        }
                      median = colvalues[ds/2];
                       for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;


                       lineChart.getData().add(series);
                  
                  dnS.setText("mPosA chart");
                  dnS.setContent(lineChart);
                setBarTab( xName,  yName,  maxx, minx,  avg);    
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load mPosEchart Chart  
    private void mPosEchart() {
            
        final CategoryAxis xAxiss = new CategoryAxis();
        final NumberAxis yAxiss = new NumberAxis();
        xAxiss.setLabel("Time");       
        yAxiss.setLabel("mPosE");

        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxiss,yAxiss);
                
        lineChart.setTitle("mPosE/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 62");
         xName = xAxiss.getLabel();
         yName = yAxiss.getLabel();

        
     ds = data.size();
    colvalues  = new int[ds];

                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), Integer.parseInt(mPosE.getCellData(k))));
                            colvalues[k] = Integer.parseInt(mPosE.getCellData(k));
                        }
                     
                      median = colvalues[ds/2];
        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                 
                  dnS.setText("mPosE chart");
                  dnS.setContent(lineChart);
                setBarTab( xName,  yName,  maxx, minx,  avg);   
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load supply5Vchart Chart  
    private void supply5Vchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("supply5V");
        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);
                
        lineChart.setTitle("supply5V/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 63");
        
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
     ds = data.size();
    colvalues1  = new Float[ds];

                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(supply5V.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(supply5V.getCellData(k));

                        }
                      median = colvalues1[ds/2];
                       for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                 
                  dnS.setText("supply5V chart");
                  dnS.setContent(lineChart);
                  setBarTab( xName,  yName,  maxx, minx,  avg);      
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load dcBusAchart Chart  
    private void dcBusAchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("dcBusA");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("dcBusA/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 64");
        xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
     colvalues1  = new Float[ds];
     
     
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(dcBusA.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(dcBusA.getCellData(k));

                        }
                      
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                 
                  dnS.setText("dcBusA chart");
                  dnS.setContent(lineChart);
                 setBarTab( xName,  yName,  maxx, minx,  avg);  
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }



    @FXML//Load dcBusEchart Chart  
    private void dcBusEchart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("dcBusE");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("dcBusE/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 65");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
    colvalues1  = new Float[ds];

                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(dcBusE.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(dcBusE.getCellData(k));

                        }
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                   
                  dnS.setText("dcBusE chart");
                  dnS.setContent(lineChart);
                  setBarTab( xName,  yName,  maxx, minx,  avg);      
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }



    @FXML//Load debug0chart Chart  
    private void debug0chart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("debug0");

        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("debug0/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 66");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
    colvalues1  = new Float[ds];
    
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(debug0.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(debug0.getCellData(k));

                        }
                      
                      median = colvalues1[ds/2];
                       for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                   
                  dnS.setText("debug0 chart");
                  dnS.setContent(lineChart);
                  setBarTab( xName,  yName,  maxx, minx,  avg);    
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            } 
    
    
    @FXML//Load debug1chart Chart  
    private void debug1chart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("debug1");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("debug1/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 67");
        xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
     ds = data.size();
    colvalues1  = new Float[ds];
    
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(debug1.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(debug1.getCellData(k));

                        }
                      
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                
                  dnS.setText("debug1 chart");
                  dnS.setContent(lineChart);
                 setBarTab( xName,  yName,  maxx, minx,  avg);    
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load debug2chart Chart  
    private void debug2chart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("debug2");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("debug2/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 68");
        xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
         ds = data.size();
        colvalues1  = new Float[ds];
        
        
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(debug2.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(debug2.getCellData(k));
                        }
                      
                      median = colvalues1[ds/2];
                       for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                   
                  dnS.setText("debug2 chart");
                  dnS.setContent(lineChart);
                setBarTab( xName,  yName,  maxx, minx,  avg);     
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load debug2chart Chart  
    private void debug3chart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("debug3");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("debug3/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 69");
        xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
    colvalues1  = new Float[ds];
    
    
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(debug3.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(debug3.getCellData(k));
                        }
                      
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                
                  dnS.setText("debug3 chart");
                  dnS.setContent(lineChart);
                  setBarTab( xName,  yName,  maxx, minx,  avg);    
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load debug2chart Chart  
    private void debug4chart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("debug4");

        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("debug4/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 70");
        xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
     ds = data.size();
    colvalues1  = new Float[ds];
    
    
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(debug4.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(debug4.getCellData(k));
                        }
                      
                      median = colvalues1[ds/2];
                       
        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                
                  dnS.setText("debug4 chart");
                  dnS.setContent(lineChart);
               
                    setBarTab( xName,  yName,  maxx, minx,  avg);    
                                      try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load ctrl1Achart Chart  
    private void ctrl1Achart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("ctrl1A");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("ctrl1A/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 72");
        
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
    ds = data.size();
    colvalues1  = new Float[ds];
    
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(ctrl1A.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(ctrl1A.getCellData(k));


                        }
                      
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                   
                  dnS.setText("ctrl1A chart");
                  dnS.setContent(lineChart);
                 setBarTab( xName,  yName,  maxx, minx,  avg);   
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load ctrl1Echart Chart  
    private void ctrl1Echart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("ctrl1E");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("ctrl1E/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 72");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
     colvalues1  = new Float[ds];
     
     
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(ctrl1E.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(ctrl1E.getCellData(k));

                        }
                      median = colvalues1[ds/2]; 
        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                 
                  dnS.setText("ctrl1E chart");
                  dnS.setContent(lineChart);
                setBarTab( xName,  yName,  maxx, minx,  avg); 
                                  try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load ctrl2Achart Chart  
    private void ctrl2Achart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("ctrl2A");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("ctrl2A/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 73");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
      colvalues1  = new Float[ds];
      
      
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(ctrl2A.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(ctrl2A.getCellData(k));
                        }
                      
                      median = colvalues1[ds/2];
                       for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                 
                  dnS.setText("ctrl2A chart");
                  dnS.setContent(lineChart);
              setBarTab( xName,  yName,  maxx, minx,  avg);  
                                   try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load ctrl2Echart Chart  
    private void ctrl2Echart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("ctrl2E");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("ctrl2E/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 74");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
    ds = data.size();
    colvalues1  = new Float[ds];
    
    
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(ctrl2E.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(ctrl2E.getCellData(k));

                        }
                      
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                  
                  dnS.setText("ctrl2E chart");
                  dnS.setContent(lineChart);
               setBarTab( xName,  yName,  maxx, minx,  avg);    
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load ctrl3Achart Chart  
    private void ctrl3Achart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("ctrl3A");

        final LineChart<String,Number> lineChart = 
                new LineChart<String,Number>(xAxis,yAxis);
                
        lineChart.setTitle("ctrl3A/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 75");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
     colvalues1  = new Float[ds];
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(ctrl3A.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(ctrl3A.getCellData(k));

                        }
                     median = colvalues1[ds/2];  
        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                  
                  dnS.setText("ctrl3A chart");
                  dnS.setContent(lineChart);
               setBarTab( xName,  yName,  maxx, minx,  avg);   
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load ctrl3Echart Chart  
    private void ctrl3Echart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("ctrl3E");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("ctrl3E/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 76");
        xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
    int ds = data.size();
     colvalues1  = new Float[ds];

                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(ctrl3E.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(ctrl3E.getCellData(k));
                        }
                      
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                
                  dnS.setText("ctrl3E chart");
                  dnS.setContent(lineChart);
               setBarTab( xName,  yName,  maxx, minx,  avg);     
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load ctrl4Achart Chart  
    private void ctrl4Achart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("ctrl4A");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("ctrl4A/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 77");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
    int ds = data.size();
        colvalues1  = new Float[ds];
        
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(ctrl4A.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(ctrl4A.getCellData(k));
                        }
                      
                      median = colvalues1[ds/2];
                       for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                  
                  dnS.setText("ctrl4A chart");
                  dnS.setContent(lineChart);
                setBarTab( xName,  yName,  maxx, minx,  avg);  
                                      try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            } 
            }
    
    
    
    @FXML//Load ctrl4Echart Chart  
    private void ctrl4Echart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("ctrl4E");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("ctrl4E/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 78");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
    int ds = data.size();
    colvalues1  = new Float[ds];
    
    
                      for (int k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(ctrl4E.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(ctrl4E.getCellData(k));
                        }
                      
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                
                  dnS.setText("ctrl4E chart");
                  dnS.setContent(lineChart);
                   setBarTab( xName,  yName,  maxx, minx,  avg);   
                                          try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    
    @FXML//Load ctrl5Achart Chart  
    private void ctrl5Achart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("ctrl5A");
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("ctrl5A/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 79");
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();

        
     ds = data.size();
      colvalues1  = new Float[ds];
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Float.parseFloat(ctrl5A.getCellData(k)))));
                            colvalues1[k] = Float.parseFloat(ctrl5A.getCellData(k));

                        }
                      
                      median = colvalues1[ds/2];
                        for( k = 0; k < colvalues1.length; k++){
            minx = colvalues1[0];
            maxx = colvalues1[0];
            for ( z = 1; z < colvalues1.length - 1; z++){
            if (colvalues1[z +1] < minx) {
            temp = minx;
            minx = colvalues1[z+1];
        }
            }
            
            if (colvalues1[k] > maxx){
             temp = maxx;
             maxx = colvalues1[k];
            }
        }
        avg = (maxx + minx)/2.0;

                       lineChart.getData().add(series);
                  
                  dnS.setText("ctrl5A chart");
                  dnS.setContent(lineChart);
             setBarTab( xName,  yName,  maxx, minx,  avg); 
                                    try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
    
    
    @FXML//Load ctrl5Echart Chart  
    private void ctrl5Echart() {
            
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Time");       
        yAxis.setLabel("ctrl5E");
        
        
        final LineChart<String,Number> lineChart = 
                new LineChart<>(xAxis,yAxis);
                
        lineChart.setTitle("ctrl5E/time");
                                
        XYChart.Series series = new XYChart.Series();
        series.setName("Portfolio 80");
        
         xName = xAxis.getLabel();
         yName = yAxis.getLabel();
        
     ds = data.size();
  Double[] colvalues  = new Double[ds];
                      for ( k = 0; k < ds; k ++)
                        {
                            series.getData().add(new XYChart.Data(time.getCellData(k), (Double.parseDouble(ctrl5E.getCellData(k)))));
                            colvalues[k] = Double.parseDouble(ctrl5E.getCellData(k));
                        }
                      
                      median = colvalues[ds/2];
                        for( k = 0; k < colvalues.length; k++){
            minx = colvalues[0];
            maxx = colvalues[0];
            for ( z = 1; z < colvalues.length - 1; z++){
            if (colvalues[z +1] < minx) {
            temp = minx;
            minx = colvalues[z+1];
        }
            }
            
            if (colvalues[k] > maxx){
             temp = maxx;
             maxx = colvalues[k];
            }
        }
        avg = (maxx + minx)/2.0;
                       lineChart.getData().add(series);
                 
                  dnS.setText("ctrl5E chart");
                  dnS.setContent(lineChart);
                setBarTab( xName,  yName,  maxx, minx,  avg);  
                                      try {
                createTable(subCatPart, yName, maxx, minx, avg, mode1, median);
            } catch (BadElementException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            } 
            }
    
    
    
    
    
 }    

        


