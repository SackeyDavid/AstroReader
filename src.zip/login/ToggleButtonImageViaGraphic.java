/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

/**
 *
 * @author David
// */
//import    javafx.application.Application;
//import javafx.beans.binding.Bindings;
//import javafx.scene.*;
//import javafx.scene.control.ToggleButton;
//import javafx.scene.image.*;
//import javafx.scene.layout.StackPaneBuilder;
//import javafx.stage.Stage;
//public class ToggleButtonImageViaGraphic extends Application {


//
//  public static void main(String[] args) throws Exception { launch(args); }
//  @Override public void start(final Stage stage) throws Exception {
//    final ToggleButton toggle      = new ToggleButton();
//    final Image        unselected  = new Image(
//      "/login/background.gif"
//    );
//    final Image        selected    = new Image(
//      "/login/guaze.gif"
//    );
//    final ImageView    toggleImage = new ImageView();
//    toggle.setGraphic(toggleImage);
//    toggleImage.imageProperty().bind(Bindings
//      .when(toggle.selectedProperty())
//        .then(selected)
//        .otherwise(unselected)
//    );
//
//    stage.setScene(new Scene(
//      StackPaneBuilder.create()
//        .children(toggle)
//        .style("-fx-padding:10; -fx-background-color: cornsilk;")
//        .build()
//    ));
//    stage.show();
////  }
//}

