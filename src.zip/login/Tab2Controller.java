/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author David
 */
public class Tab2Controller {
                
            @FXML AnchorPane ac1;  
            
          @FXML
          LineChart<Number, Number> lc1;
            
          XYChart.Series <Number, Number> series = new XYChart.Series<Number, Number>();

    
          
          
}
