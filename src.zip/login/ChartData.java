/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.util.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.XYChart.Data;

/**
 *
 * @author David
 */
public class ChartData {
//private ObservableList<String> series;
//private ObservableList<logEntry> data;
//
//public ChartData(){
//    series = FXCollections.observableArrayList();
//    data = FXCollections.observableArrayList();
//}
//
//public ObservableList<logEntry> getData(){
//    return data;
//}
//
//public int getlogEntryValuesSize(){
//    return data.get(0).getValues().size();
//}
//
//public void setlogEntry(ObservableList<logEntry> data) {
//    this.data = data;
//}
//
//public void setBindings(){
//
//    ObservableList<logEntry> tempData = FXCollections.observableArrayList(item -> {
//        Observable[] obs = new Observable[item.getValues().size() + 1];
//        obs[0] = item.timeProperty();
//
//        for(int i = 0; i < item.getValues().size(); i++){
//            obs[i+1] = item.getProperty(i);
//        }
//
//        return obs;
//    });
//
//    tempData.addAll(data);
//    setlogEntry(tempData);
//}
}
