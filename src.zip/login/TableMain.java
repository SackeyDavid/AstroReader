/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

/**
 *
 * @author David
 */


import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.fxml.FXMLLoader;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.stage.StageStyle;


public class TableMain extends Application {
    
   
    @Override
    public void start(Stage pStage) {
        try {
            AnchorPane root = (AnchorPane)FXMLLoader.load(getClass().getResource("Table.fxml"));
            Scene scene = new Scene(root);
            pStage.setScene(scene);
            //BorderPane borderPane = new BorderPane();
          
            //pStage.initStyle(StageStyle.UNDECORATED);
            scene.getStylesheets().add(getClass().getResource("login.css").toExternalForm());
            pStage.setResizable(true);
            //set icon of the application
            Image applicationIcon = new Image(getClass().getResourceAsStream("radio.png"));
            pStage.getIcons().add(applicationIcon);
            pStage.setTitle("Log Entry");
            pStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
    

