/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

/**
 *
 * @author David
 */


import javafx.fxml.Initializable;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;



import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;



public class TableController implements Initializable {


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
        }
    //table.setPlaceholder(new Label("Select File then Click Load or Alt + L to Load Data"));
        @FXML
        AnchorPane anchorpane4;
                
        @FXML        
        BorderPane borderpane1;
        
        @FXML        
        MenuBar menubar;
                
        @FXML        
        Menu file;
                
        @FXML        
        MenuItem close;
        
        @FXML        
        MenuItem load;
                
        @FXML        
        Menu edit;
                
        @FXML        
        MenuItem delete;
                
        @FXML        
        Menu help;
                
        @FXML        
        MenuItem about;
                
        @FXML        
        AnchorPane anchorpane;
                
        @FXML        
        Label tableview;
        
        @FXML
        Separator separator2;

        @FXML        
        Button print;
                
        @FXML        
        ScrollPane scrollpane3;
                
        @FXML        
        AnchorPane anchorpane3;
                
        @FXML        
        Separator seperator1;
                
        @FXML        
        Label radiotelescope;
                
        @FXML        
        ScrollPane scrollpane1;
                
        @FXML        
        AnchorPane anchorpane1;
                
        @FXML        
        ScrollPane scrollpane2;
                
        @FXML
        AnchorPane anchorpane2;
                
        @FXML        
        Label positioninformation;
        
        @FXML        
        Label at;
                
        @FXML        
        Label on;
                
        @FXML        
        ComboBox combo1;
                
        @FXML        
        ComboBox combox2;
        
        @FXML        
        Label speeddetails;
                
        @FXML        
        RadioButton seedetailspdf;
        
        @FXML        
        Button next;
                
        @FXML        
        Button edit2;
        
        @FXML        
        Button save;
        
        @FXML        
        Button closevbox;
        
        @FXML        
        TextArea shortdirection;
        
        @FXML        
        private Button previous;
                
        @FXML        
        private Label processingcommand;
        
        @FXML private VBox vbxDir;
        
    @FXML private AnchorPane apCSV;
    @FXML private ScrollPane scrollpane;
    @FXML private Button wide;
            
//    @FXML public TextField txfFName;
//    @FXML public TextField txfLName;
//    @FXML public TextField txfPNum;
//    @FXML public TextField txfEMail;
    //@FXML private VBox vbxDir;

    @FXML public TableView<logEntry> table;
    @FXML public TableColumn <logEntry, Integer>    time;
    @FXML public TableColumn <logEntry,Integer>     upSlow;
    @FXML public TableColumn <logEntry,Integer>     upFast;
    @FXML public TableColumn <logEntry,Integer>     dnSlow;
    @FXML public TableColumn <logEntry, Integer>    dnFast;
    @FXML public TableColumn <logEntry, Integer>    rtSlow;
    @FXML public TableColumn <logEntry, Integer>    rtFast;
    @FXML public TableColumn <logEntry, Integer>    ltSlow;
    @FXML public TableColumn <logEntry, Integer>    ltFast;
    @FXML public TableColumn <logEntry, Integer>    feedAcc;
    @FXML public TableColumn <logEntry, Integer>    stow;
    @FXML public TableColumn <logEntry, Integer>    remote;
    @FXML public TableColumn <logEntry, Integer>    local;
    @FXML public TableColumn <logEntry, Integer>    VtripE380;
    @FXML public TableColumn <logEntry, Integer>    brkRoffE;
    @FXML public TableColumn <logEntry, Integer>    VonE24;
    @FXML public TableColumn <logEntry, Integer>    Voff380;
    @FXML public TableColumn <logEntry, Integer>    VtripA380;
    @FXML public TableColumn <logEntry, Integer>    brkRoffA;
    @FXML public TableColumn <logEntry, Integer>    VonA24;
    @FXML public TableColumn <logEntry, Integer>    Von24;
    @FXML public TableColumn <logEntry, Integer>    overHlim;
    @FXML public TableColumn <logEntry, Integer>    tBoxOver;
    @FXML public TableColumn <logEntry, Integer>    notEstop;
    @FXML public TableColumn <logEntry, Integer>    overlap1;
    @FXML public TableColumn <logEntry, Integer>    enReqE;
    @FXML public TableColumn <logEntry, Integer>    enE;
    @FXML public TableColumn <logEntry, Integer>    topHlim;
    @FXML public TableColumn <logEntry, Integer>    botHlim;
    @FXML public TableColumn <logEntry, Integer>    notTopFlim;
    @FXML public TableColumn <logEntry, Integer>    notBotFlim;
    @FXML public TableColumn <logEntry, Integer>    bkStow;
    @FXML public TableColumn <logEntry, Integer>    brakeE;
    @FXML public TableColumn <logEntry, Integer>    enReqA;
    @FXML public TableColumn <logEntry, Integer>    enA;
    @FXML public TableColumn <logEntry, Integer>    rtHlim;
    @FXML public TableColumn <logEntry, Integer>    ltHlim;
    @FXML public TableColumn <logEntry, Integer>    notRtFlim;
    @FXML public TableColumn <logEntry, Integer>    notLtFlim;
    @FXML public TableColumn <logEntry, Integer>    overlap2;
    @FXML public TableColumn <logEntry, Integer>    brakeA;
    @FXML public TableColumn <logEntry, Integer>    drStateA;
    @FXML public TableColumn <logEntry, Integer>    drStateE;
    @FXML public TableColumn <logEntry, Integer>    modeReq;
    @FXML public TableColumn <logEntry, Integer>    mode;
    @FXML public TableColumn <logEntry, Integer>    selState;
    @FXML public TableColumn <logEntry, Integer>    funcState;
    @FXML public TableColumn <logEntry, Integer>    ntp;
    @FXML public TableColumn <logEntry, Integer>    timeReq;
    @FXML public TableColumn <logEntry, Float>    posReqA;
    @FXML public TableColumn <logEntry, Float>    posDesA;
    @FXML public TableColumn <logEntry, Float>    posActA;
    @FXML public TableColumn <logEntry, Float>    posReqE;
    @FXML public TableColumn <logEntry, Float>    posDesE;
    @FXML public TableColumn <logEntry, Float>    posActE;
    @FXML public TableColumn <logEntry, Float>    mVelA;
    @FXML public TableColumn <logEntry, Float>    mReqA;
    @FXML public TableColumn <logEntry, Float>    mVelE;
    @FXML public TableColumn <logEntry, Float>    mReqE;
    @FXML public TableColumn <logEntry, Float>    mTorqA;
    @FXML public TableColumn <logEntry, Float>    mTorqE;
    @FXML public TableColumn <logEntry, Integer>    mPosA;
    @FXML public TableColumn <logEntry, Integer>    mPosE;
    @FXML public TableColumn <logEntry, Float>    supply5V;
    @FXML public TableColumn <logEntry, Float>    dcBusA;
    @FXML public TableColumn <logEntry, Float>    dcBusE;
    @FXML public TableColumn <logEntry, Float>    debug0;
    @FXML public TableColumn <logEntry, Float>    debug1;
    @FXML public TableColumn <logEntry, Float>    debug2;
    @FXML public TableColumn <logEntry, Float>    debug3;
    @FXML public TableColumn <logEntry, Float>    debug4;
    @FXML public TableColumn <logEntry, Float>    ctrl1A;
    @FXML public TableColumn <logEntry, Float>    ctrl1E;
    @FXML public TableColumn <logEntry, Float>    ctrl2A;
    @FXML public TableColumn <logEntry, Float>    ctrl2E;
    @FXML public TableColumn <logEntry, Float>    ctrl3A;
    @FXML public TableColumn <logEntry, Float>    ctrl3E;
    @FXML public TableColumn <logEntry, Float>    ctrl4A;
    @FXML public TableColumn <logEntry, Float>    ctrl4E;
    @FXML public TableColumn <logEntry, Float>    ctrl5A;
    @FXML public TableColumn <logEntry, Float>    ctrl5E;
    
    
    
    
    
    
    
    
            
    
    
    
    
    
    
    
    
    
    
    

    FileChooser fc = new FileChooser();
    public ArrayList<logEntry> list;
    private ListIterator<logEntry> LIT;
    private int i;

    public ObservableList<logEntry> data;

    @FXML
    private void onDir(ActionEvent e) {
        vbxDir.setVisible(true);
        vbxDir.toFront();
    }
    @FXML
    private void onClose(ActionEvent e) {
        vbxDir.setVisible(false);
    }
    
           @FXML//Clear Fields and ArrayList
    private void onWide(ActionEvent e) throws IOException {
           
//    @FXML  AnchorPane apV;
//    @FXML  ScrollPane scpane;
//    @FXML  TableView tableV;
                
//            try
//                {
//                FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("tableV.fxml"));
//                Parent root = (Parent)fxmlloader.load();
//                Stage stage = new Stage();
//                stage.setScene(new Scene(root));
//                stage.show();
//                
//                //primaryStage.close();
//                ;
//                }
//                catch(Exception es)
//                {
//                    es.printStackTrace();
//                }
//            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("tableV.fxml"));
//            Parent root = (Parent) fxmlLoader.load();
//            Stage stage = new Stage();
//            stage.initModality(Modality.APPLICATION_MODAL);
//            //stage.initStyle(StageStyle.UNDECORATED);
//            stage.setTitle("Log Entry");
//            stage.setScene(new Scene(root));  
//            stage.show();
          
    }

    @FXML//Load CSV Data
    private void onLoad(ActionEvent e)throws IOException {

        data = FXCollections.observableArrayList();//Hold data for the table

        File fileInfo = new File("F:/A_CSV/timingdata.txt");
        if(fileInfo.length()==0) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Information");
            alert.setHeaderText("");
            alert.setContentText("No Data in File at "+ fileInfo+"\n"+
            "Enter Data and Save");
            alert.showAndWait();
            return;  
        }

        fc.setTitle("Load Contacts Info");
        //fc.setInitialDirectory(new File("F:/"));
        //fc.setInitialDirectory(new File(":/A_CSV"));
        fc.setInitialFileName("timingdata.txt");
        File file = fc.showOpenDialog(null);
        if (file == null) {
        return;
        }

        String correctFile = file.getName();
        if(!(correctFile.matches("timingdata.txt"))){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Information");
            alert.setHeaderText("");
            alert.setContentText("The File at " + file + "\n\n"+
            "is NOT accociated with this application\n\n"+
            "Select the File at "+fileInfo);
            alert.showAndWait();
            return;
        }

        Path dirP = Paths.get(String.valueOf(file));
        InputStream in = Files.newInputStream(dirP);
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));

        list = new ArrayList<logEntry>();
        Scanner scan = new Scanner(reader);
        scan.useDelimiter("\\s*,\\s*");

        while (scan.hasNext()){
//           
//           String lname = scan.next();
//           String pnum = scan.next();
//           String email = scan.next();
           
                String     tim = scan.next();
                String     upSlo = scan.next();
                String     upFas = scan.next();
                String     dnSlo = scan.next();
                String     dnFas = scan.next();
                String     rtSlo = scan.next();
                String     rtFas = scan.next();
                String     ltSlo = scan.next();
                String     ltFas = scan.next();
                String     feedAc = scan.next();
                String     sto = scan.next();
                String     remot = scan.next();
                String     loca = scan.next();
                String     VtripE38 = scan.next();
                String     brkRoff = scan.next();
                String     VonE2 = scan.next();
                String     Voff38 = scan.next();
                String     VtripA38 = scan.next();
                String     brkRof = scan.next();
                String     VonA2 = scan.next();
                String     Von2 = scan.next();
                String     overHli = scan.next();
                String     tBoxOve = scan.next();
                String     notEsto = scan.next();
                String     overla1 = scan.next();
                String     enReq = scan.next();
                String     en = scan.next();
                String     topHli = scan.next();
                String     botHli = scan.next();
                String     notTopFli = scan.next();
                String     notBotFli = scan.next();
                String     bkSto = scan.next();
                String     brake = scan.next();
                String     enReq1 = scan.next();
                String     enA1 = scan.next();
                String     rtHli = scan.next();
                String     ltHli = scan.next();
                String     notRtFli = scan.next();
                String     notLtFli = scan.next();
                String     overla2 = scan.next();
                String     brakA = scan.next();
                String     drStatA = scan.next();
                String     drStatE = scan.next();
                String     modeRq = scan.next();
                String     moe = scan.next();
                String     selStae = scan.next();
                String     funcStae = scan.next();
                String     np = scan.next();
                String     timeRq = scan.next();
                String       posReA = scan.next();
                String       posDeA = scan.next();
                String       posAcA = scan.next();
                String       posReE = scan.next();
                String       posDeE = scan.next();
                String       posAcE = scan.next();
                String       mVeA = scan.next();
                String       mReA = scan.next();
                String       mVeE = scan.next();
                String       mReE = scan.next();
                String       mTorA = scan.next();
                String       mTorE = scan.next();
                String       mPoA = scan.next();
                String       mPoE = scan.next();
                String       suppl5V = scan.next();
                String       dcBuA = scan.next();
                String       dcBuE = scan.next();
                String       debu0 = scan.next();
                String       debu1 = scan.next();
                String       debu2 = scan.next();
                String       debu3 = scan.next();
                String       debu4 = scan.next();
                String       ctrl1  = scan.next();
                String       ctrl2 = scan.next();
                String       ctrl3 = scan.next();
                String       ctrl4 = scan.next();
                String       ctrl5 = scan.next();
                String       ctrl6 = scan.next();
                String       ctrl7 = scan.next();
                String       ctrl8 = scan.next();
                String       ctrl9 = scan.next();
                String       ctrl10 = scan.next();
                
//
//           txfFName.setText(String.valueOf(fname));
//           txfLName.setText(String.valueOf(lname));
//           txfPNum.setText(String.valueOf(pnum));
//           txfEMail.setText(String.valueOf(email));


           list.add(new logEntry(tim,upSlo,upFas,dnSlo,dnFas,rtSlo, rtFas,ltSlo,ltFas, feedAc,sto,remot,loca, VtripE38,brkRoff,VonE2,Voff38,VtripA38,brkRof,VonA2,Von2, overHli,tBoxOve,notEsto,overla1, enReq,en,topHli,botHli,notTopFli,notBotFli,bkSto,brake, enReq1,enA1,rtHli,ltHli,notRtFli,notLtFli,overla2,brakA, drStatA,drStatE,modeRq,moe,selStae,funcStae,np, timeRq,posReA,posDeA,posAcA,posReE,posDeE,posAcE, mVeA,mReA,mVeE,mReE,mTorA,mTorE,mPoA,mPoE, suppl5V, dcBuA,dcBuE, debu0,debu1,debu2,debu3,debu4, ctrl1,ctrl2,ctrl3,ctrl4,ctrl5,ctrl6,ctrl7,ctrl8,ctrl9,ctrl10));
           data.add(new logEntry(tim,upSlo,upFas,dnSlo,dnFas,rtSlo, rtFas,ltSlo,ltFas, feedAc,sto,remot,loca, VtripE38,brkRoff,VonE2,Voff38,VtripA38,brkRof,VonA2,Von2, overHli,tBoxOve,notEsto,overla1, enReq,en,topHli,botHli,notTopFli,notBotFli,bkSto,brake, enReq1,enA1,rtHli,ltHli,notRtFli,notLtFli,overla2,brakA, drStatA,drStatE,modeRq,moe,selStae,funcStae,np, timeRq,posReA,posDeA,posAcA,posReE,posDeE,posAcE, mVeA,mReA,mVeE,mReE,mTorA,mTorE,mPoA,mPoE, suppl5V, dcBuA,dcBuE, debu0,debu1,debu2,debu3,debu4, ctrl1,ctrl2,ctrl3,ctrl4,ctrl5,ctrl6,ctrl7,ctrl8,ctrl9,ctrl10));
           table.setItems(data);

           time.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("time"));
           upSlow.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("upSlow"));
           upFast.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("upFast"));
           dnSlow.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("dnSlow"));
           dnFast.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("dnFast"));
           rtSlow.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("rtSlow"));
           rtFast.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("rtFast"));
           ltSlow.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("ltSlow"));
           ltFast.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("ltFast"));
           feedAcc.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("feedAcc"));
           stow.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("stow"));
           remote.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("remote"));
           local.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("local"));
           VtripE380.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("VtripE380"));
           brkRoffE.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("brkRoffE"));
           VonE24.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("VonE24"));
           Voff380.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("Voff380"));
           VtripA380.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("VtripA380"));
           brkRoffA.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("brkRoffA"));
           VonA24.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("VonA24"));
           Von24.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("Von24"));
           overHlim.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("overHlim"));
           tBoxOver.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("tBoxOver"));
           notEstop.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("notEstop"));
           overlap1.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("overlap1"));
           enReqE.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("enReqE"));
           enE.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("enE"));
           topHlim.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("topHlim"));
           botHlim.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("botHlim"));
           notTopFlim.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("notTopFlim"));
           notBotFlim.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("notBotFlim"));
           bkStow.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("bkStow"));
           brakeE.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("brakeE"));
           enReqA.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("enReqA"));
           enA.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("enA"));
           rtHlim.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("rtHlim"));
           ltHlim.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("ltHlim"));
           notRtFlim.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("notRtFlim"));
           notLtFlim.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("notLtFlim"));
           overlap2.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("overlap2"));
           brakeA.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("brakeA"));
           drStateA.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("drStateA"));
           drStateE.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("drStateE"));
           modeReq.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("modeReq"));
           mode.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("mode"));
           selState.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("selState"));
           funcState.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("funcState"));
           ntp.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("ntp"));
           timeReq.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("timeReq"));
           posReqA.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("posReqA"));
           posDesA.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("posDesA"));
           posActA.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("posActA"));
           posReqE.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("posReqE"));
           posDesE.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("posDesE"));
           posActE.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("posActE"));
           mVelA.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("mVelA"));
           mReqA.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("mReqA"));
           mVelE.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("mVelE"));
           mReqE.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("mReqE"));
           mTorqA.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("mTorqA"));
           mTorqE.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("mTorqE"));
           mPosA.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("mPosA"));
           mPosE.setCellValueFactory(new PropertyValueFactory <logEntry, Integer>("mPosE"));
           supply5V.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("supply5V"));
           dcBusA.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("dcBusA"));
          dcBusE.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("dcBusE"));
          debug0.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("debug0"));
          debug1.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("debug1"));
          debug2.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("debug2"));
          debug3.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("debug3"));
          debug4.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("debug4"));
          ctrl1A.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("ctrl1A"));
          ctrl1E.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("ctrl1E"));
          ctrl2A.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("ctrl2A"));
          ctrl2E.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("ctrl2E"));
          ctrl3A.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("ctrl3A"));
          ctrl3E.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("ctrl3E"));
          ctrl4A.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("ctrl4A"));
          ctrl4E.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("ctrl4E"));
          ctrl5A.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("ctrl5A"));
          ctrl5E.setCellValueFactory(new PropertyValueFactory <logEntry, Float>("ctrl5E"));

        }
        scan.close();

        LIT = list.listIterator();                  
        if (LIT.hasNext()){          
            logEntry p = LIT.next();
            getlogEntry(p); 
        } 
    }

    @FXML//This code removes data from the ArrayList and RE-Writes to the
     //People.csv file the file is deleted first then rewritten
    private void onRemove(ActionEvent e)throws IOException{
//
//    if(txfFName.getText().isEmpty()||txfLName.getText().isEmpty()||txfPNum.getText().isEmpty()||txfEMail.getText().isEmpty()) {
//        Alert alert = new Alert(Alert.AlertType.WARNING);
//        alert.setTitle("Information");
//        alert.setHeaderText("");
//        alert.setContentText("No Data Present to REMOVE\n"+
//        "Click LOAD to Obtain Data");
//        alert.showAndWait();
//        return; 
//    }

    list.get(i);
    list.remove(i);

    if(0 == list.size()){
    Path path = FileSystems.getDefault().getPath("F:/A_CSV", "People.txt");
    Files.delete(path);
        onClear(e);
        list.clear();
    return;
    }else if(i == list.size()){     
        i = i - 1;
    }
    logEntry p = list.get(i);
        getlogEntry(p);
        logEntry dat;

        for(int r = 0; r <list.size(); r++){
        dat = list.get(r);  
        }  
       Path path = FileSystems.getDefault().getPath("C:/A_CSV", "People.csv");
       Files.delete(path);

       File file = new File("C:/A_CSV/People.csv");
            if(!file.exists()){
            file.createNewFile();
        }

        FileWriter fileWriter = new FileWriter(file.getPath(),true);
        BufferedWriter bufferWritter = new BufferedWriter(fileWriter);  
        Iterator<logEntry> LIT = list.iterator();
            while(LIT.hasNext()) {
                dat = LIT.next();
                String d = dat.toString();
                bufferWritter.write(d);
        }

        bufferWritter.close();
        onClear(e);
        //list.clear();//this is done by onClear(e)
        //txfFName.requestFocus();
    }

    @FXML//Scroll forward through the ArrayList
    private void onNext(ActionEvent e) {

        if (list == null || list.size() == 0) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Information");
        alert.setHeaderText("");
        alert.setContentText("Load Data First");
        alert.showAndWait();
        return;
        }

        if (i == list.size()- 1) {
        i = 0;
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Information");
        alert.setHeaderText("");
        alert.setContentText("Last Record in File");
        alert.showAndWait();
        i= list.size()-1;
        return;
        }else {
        i = i + 1;
        }
            logEntry p = list.get(i);
            getlogEntry(p); 
    }

    @FXML//Scroll backwards through the ArrayList
    private void onPrevious(ActionEvent e) {

        if (list == null || list.size() == 0) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Information");
        alert.setHeaderText("");
        alert.setContentText("Load Data First");
        alert.showAndWait();
        return;
        }

        if (i == 0) {
        i = list.size()-1;
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Information");
        alert.setHeaderText("");
        alert.setContentText("First Record in File");
        alert.showAndWait();
        i=0;
        return;
        }else {
        i = i - 1 ;
        }
            logEntry p = list.get(i); 
            getlogEntry(p);
    }

    //Helper for Contacts Class
    private void getlogEntry(logEntry p){
//        txfFName.setText("" + p.getFName());
//        txfLName.setText("" + p.getLName());
//        txfPNum.setText ("" + p.getPnum());
//        txfEMail.setText("" + p.getEmail());    
    }

    @FXML
    private void oneSave(ActionEvent e) throws IOException{

//    if(txfFName.getText().isEmpty() || txfLName.getText().isEmpty() || txfPNum.getText().isEmpty() || txfEMail.getText().isEmpty()) {
//        Alert alert = new Alert(Alert.AlertType.WARNING);
//        alert.setTitle("Information");
//        alert.setHeaderText("");
//        alert.setContentText("No DATA entered\n"+
//        "ENTER new data and Alt + S to SAVE");
//        alert.showAndWait();
//
//        if(txfFName.getText().isEmpty()) {
//            txfFName.requestFocus();
//            return;
//        }
//        if(txfLName.getText().isEmpty()) {
//            txfLName.requestFocus();
//            return;
//        }
//        if(txfPNum.getText().isEmpty()) {
//            txfPNum.requestFocus();
//            return;
//        }
//        if(txfEMail.getText().isEmpty()) {
//            txfEMail.requestFocus();
//            return;
//        }   
//    }

//    String fname = txfFName.getText().trim();
//    String lname = txfLName.getText().trim();
//    String pnum = txfPNum.getText().trim();
//    String email = txfEMail.getText().trim();
//    String data = (fname + "," + lname + "," + pnum + "," + email + "," + '\r');

    File dirPath = new File("C:/A_CSV");
    dirPath.mkdirs();//Make the directory

    File file = new File(dirPath,"People.csv");
    if(!file.exists()){
       file.createNewFile();//Create and empty text file
    }
//
//    Alert alert1 = new Alert(AlertType.CONFIRMATION);
//    alert1.setTitle("Confirm Save");
//    alert1.setHeaderText("");
//    alert1.setContentText("Select OK to Save Data");
//    //Alert Do You Want to SAVE
//    Optional<ButtonType> result = alert1.showAndWait();
//    if (result.get() == ButtonType.OK){
//        FileWriter fileWriter = new FileWriter(file.getPath(),true);
//        try (BufferedWriter bufferWritter = new BufferedWriter(fileWriter)) {
//           // bufferWritter.write(data);
//
//        //Alert that you did SAVE too many Alerts!          
//////        Alert alert = new Alert(AlertType.INFORMATION);
//////        alert.setTitle("Information Dialog");
//////        alert.setHeaderText(null);
//////        alert.setContentText("Data Saved");
//////        alert.showAndWait();
//////        txfFName.setText("");
//////        txfLName.setText("");
//////        txfPNum.setText("");
//////        txfEMail.setText("");
//////        txfFName.requestFocus();
//////        table.getItems().clear();//Clears the table
//    }
//
//    } else {
//        return;
//        //if you did not save do we clear the entered data ?
//        // ... user chose CANCEL or closed the dialog
//    }
    }

    @FXML//Clear Fields and ArrayList
    private void onClear(ActionEvent e) {

//    if(txfFName.getText().isEmpty()||txfLName.getText().isEmpty()||txfPNum.getText().isEmpty()||txfEMail.getText().isEmpty()) {
//        Alert alert = new Alert(Alert.AlertType.WARNING);
//        alert.setTitle("Information");
//        alert.setHeaderText("");
//        alert.setContentText("No Data Present to CLEAR\n"+
//        "Click LOAD to Obtain Data");
//        alert.showAndWait();
//        return; 
//    }
//    table.getItems().clear();
//    i=0;
//    list.clear();
//    txfFName.setText("");
//    txfLName.setText("");
//    txfPNum.setText("");
//    txfEMail.setText("");
//    txfFName.requestFocus();
    }
    

    }

